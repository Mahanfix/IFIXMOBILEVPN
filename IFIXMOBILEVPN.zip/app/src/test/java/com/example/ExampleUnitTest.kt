package com.example

import com.example.core.V2RayParser
import com.example.core.XrayConfigBuilder
import com.example.data.model.ServerEntity
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun parseVlessRealityLink_isCorrect() {
        val link = "vless://7f2a58b1-3e42-4f11-893e-a4c129e71b20@de01.ifixvpn.net:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=speed.cloudflare.com&fp=chrome&pbk=E3z-fQ1K7bS09qO9W3_XqA108L9x48563885abcdef&sid=6ba7b810&type=tcp#🇩🇪%20IFIX%20DE%2001%20-%20Frankfurt"
        val server = V2RayParser.parseLink(link)

        assertNotNull(server)
        assertEquals("de01.ifixvpn.net", server?.host)
        assertEquals(443, server?.port)
        assertEquals("vless", server?.protocol)
        assertEquals("reality", server?.security)
        assertEquals("DE", server?.countryCode)
        assertEquals("🇩🇪", V2RayParser.getCountryFlag(server!!.countryCode))
    }

    @Test
    fun parseTrojanLink_isCorrect() {
        val link = "trojan://ifix-secret-password-tr01@tr01.ifixvpn.net:443?security=tls&sni=tr01.ifixvpn.net&type=tcp#🇹🇷%20IFIX%20TR%2001%20-%20Istanbul"
        val server = V2RayParser.parseLink(link)

        assertNotNull(server)
        assertEquals("tr01.ifixvpn.net", server?.host)
        assertEquals(443, server?.port)
        assertEquals("trojan", server?.protocol)
        assertEquals("TR", server?.countryCode)
    }

    @Test
    fun generateXrayJsonConfig_isValidJson() {
        val server = ServerEntity(
            name = "Test Server",
            countryName = "Germany",
            countryCode = "DE",
            host = "de01.ifixvpn.net",
            port = 443,
            protocol = "vless",
            security = "reality"
        )

        val jsonString = XrayConfigBuilder.buildJsonConfig(server)
        val json = JSONObject(jsonString)

        assertTrue(json.has("inbounds"))
        assertTrue(json.has("outbounds"))
        assertTrue(json.has("routing"))
        assertTrue(json.has("dns"))
    }
}

