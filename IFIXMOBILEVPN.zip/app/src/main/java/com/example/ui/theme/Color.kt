package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Backgrounds & Surfaces
val BackgroundDark = Color(0xFF060A14)
val SurfaceDark = Color(0xFF0D162B)
val SurfaceCardDark = Color(0xFF13203E)
val SurfaceCardBorder = Color(0xFF22355F)
val SurfaceGlass = Color(0x99111D38)

// Brand Accents
val BrandCyan = Color(0xFF00F0FF)
val BrandCyanDark = Color(0xFF00B4D8)
val BrandBlue = Color(0xFF2563EB)
val BrandIndigo = Color(0xFF4F46E5)

// Status Colors
val StatusConnected = Color(0xFF00E676)
val StatusConnectedGlow = Color(0x4000E676)
val StatusConnecting = Color(0xFFFFB300)
val StatusConnectingGlow = Color(0x40FFB300)
val StatusDisconnected = Color(0xFFFF3B69)
val StatusDisconnectedGlow = Color(0x40FF3B69)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val TextDisabled = Color(0xFF475569)

