package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberCard
import com.example.ui.theme.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    var selectedPlan by remember { mutableStateOf("Premium") }
    var maxDevices by remember { mutableIntStateOf(2) }
    var trafficLimitGB by remember { mutableDoubleStateOf(100.0) }
    var generatedKey by remember { mutableStateOf("") }
    val snackbarHostState = remember { SnackbarHostState() }

    Scaffold(
        containerColor = BackgroundDark,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text("پنل مدیریت لایسنس‌ها (Admin)", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, "بازگشت", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        },
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "صدور لایسنس جدید IFIXVPN",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "مشخصات پلن را مشخص کرده و کلید معتبر تولید نمایید:",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )

                // Plan Select
                Text(text = "نوع پلن:", color = TextSecondary, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Pro" to 50.0, "Premium" to 100.0, "VIP" to 250.0).forEach { (plan, traffic) ->
                        FilterChip(
                            selected = selectedPlan == plan,
                            onClick = {
                                selectedPlan = plan
                                trafficLimitGB = traffic
                                maxDevices = if (plan == "VIP") 4 else if (plan == "Premium") 2 else 1
                            },
                            label = { Text(plan) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BrandCyan,
                                containerColor = SurfaceDark
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Max Devices
                Text(text = "تعداد مجاز دستگاه‌ها: $maxDevices دستگاه", color = TextSecondary, fontSize = 13.sp)
                Slider(
                    value = maxDevices.toFloat(),
                    onValueChange = { maxDevices = it.toInt() },
                    valueRange = 1f..6f,
                    steps = 4,
                    colors = SliderDefaults.colors(thumbColor = BrandCyan, activeTrackColor = BrandCyan)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Traffic Limit
                Text(text = "حجم ترافیک: ${trafficLimitGB.toInt()} گیگابایت", color = TextSecondary, fontSize = 13.sp)
                Slider(
                    value = trafficLimitGB.toFloat(),
                    onValueChange = { trafficLimitGB = it.toDouble() },
                    valueRange = 20f..500f,
                    steps = 23,
                    colors = SliderDefaults.colors(thumbColor = BrandCyan, activeTrackColor = BrandCyan)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val randomHex = UUID.randomUUID().toString().take(4).uppercase()
                        generatedKey = "IFIX-${selectedPlan.uppercase()}-2026-$randomHex"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("admin_generate_key_btn"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.VpnKey, null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تولید و ثبت لایسنس", color = Color.Black, fontWeight = FontWeight.Bold)
                }

                if (generatedKey.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Surface(
                        color = SurfaceDark,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, BrandCyan.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("لایسنس تولیدشده:", color = TextSecondary, fontSize = 11.sp)
                                Text(generatedKey, color = BrandCyan, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = {
                                clipboardManager.setText(AnnotatedString(generatedKey))
                            }) {
                                Icon(Icons.Default.ContentCopy, "کپی", tint = BrandCyan)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}
