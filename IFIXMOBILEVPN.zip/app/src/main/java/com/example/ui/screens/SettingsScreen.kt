package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.AppSettings
import com.example.ui.components.CyberCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToAdmin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsState()
    var showBackendDialog by remember { mutableStateOf(false) }
    var inputBackendUrl by remember { mutableStateOf(settings.backendUrl) }

    Scaffold(
        containerColor = BackgroundDark,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "تنظیمات پیشرفته",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, "بازگشت", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        },
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // 1. Connection & Security
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "امنیت و اتصال",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                SwitchSettingRow(
                    title = "کلید قطع اضطراری (Kill Switch)",
                    subtitle = "مسدودسازی کل ترافیک در صورت قطع موقت VPN",
                    checked = settings.killSwitchEnabled,
                    onCheckedChange = { viewModel.setKillSwitch(it) }
                )

                HorizontalDivider(color = SurfaceCardBorder, modifier = Modifier.padding(vertical = 10.dp))

                SwitchSettingRow(
                    title = "اتصال خودکار هنگام اجرا",
                    subtitle = "اتصال سریع به بهترین سرور به محض باز شدن برنامه",
                    checked = settings.autoConnectOnLaunch,
                    onCheckedChange = { viewModel.setAutoConnect(it) }
                )

                HorizontalDivider(color = SurfaceCardBorder, modifier = Modifier.padding(vertical = 10.dp))

                SwitchSettingRow(
                    title = "اجرا پس از روشن شدن گوشی",
                    subtitle = "فعال شدن خودکار پس از ریستارت دستگاه",
                    checked = settings.startOnBoot,
                    onCheckedChange = { viewModel.setStartOnBoot(it) }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 2. DNS & Routing
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "شبکه و DNS",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                // DNS Selector
                val dnsOptions = listOf("1.1.1.1" to "Cloudflare (1.1.1.1)", "8.8.8.8" to "Google (8.8.8.8)", "9.9.9.9" to "Quad9 (9.9.9.9)")
                Text(text = "سرور DNS رمزنگاری‌شده:", color = TextSecondary, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))

                dnsOptions.forEach { (ip, label) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = settings.dnsServer == ip,
                            onClick = { viewModel.setDns(ip) },
                            colors = RadioButtonDefaults.colors(selectedColor = BrandCyan)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = label, color = TextPrimary, fontSize = 14.sp)
                    }
                }

                HorizontalDivider(color = SurfaceCardBorder, modifier = Modifier.padding(vertical = 10.dp))

                // Routing Mode
                Text(text = "حالت روتینگ ترافیک:", color = TextSecondary, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = settings.routingMode == "bypass_domestic",
                        onClick = { viewModel.setRoutingMode("bypass_domestic") },
                        label = { Text("دور زدن سایت‌های داخلی (IR/LAN)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BrandCyan,
                            containerColor = SurfaceDark
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    FilterChip(
                        selected = settings.routingMode == "global",
                        onClick = { viewModel.setRoutingMode("global") },
                        label = { Text("عبور کل ترافیک (Global)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BrandCyan,
                            containerColor = SurfaceDark
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Backend & Admin Settings
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "سرور و ابزار توسعه‌دهنده",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    onClick = {
                        inputBackendUrl = settings.backendUrl
                        showBackendDialog = true
                    },
                    color = SurfaceDark,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SurfaceCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CloudQueue, null, tint = BrandCyan, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("آدرس API سرور", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(settings.backendUrl, color = TextSecondary, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.Edit, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    onClick = onNavigateToAdmin,
                    color = SurfaceDark,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SurfaceCardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_panel_button")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AdminPanelSettings, null, tint = StatusConnecting, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("پنل مدیریت و تست لایسنس‌ها (Admin)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("تولید لایسنس جدید، بررسی و مسدودسازی", color = TextSecondary, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.ChevronLeft, null, tint = TextSecondary, modifier = Modifier.size(20.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4. About Info
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text("درباره IFIXVPN", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "نسخه: 2.5.0 (Build 2026)\nتوسعه‌داده‌شده اختصاصی برای برند IFIX MOBILE بر پایه هسته قدرتمند Xray-core.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }

    if (showBackendDialog) {
        AlertDialog(
            onDismissRequest = { showBackendDialog = false },
            containerColor = SurfaceCardDark,
            title = { Text("تغییر آدرس سرور API", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = inputBackendUrl,
                    onValueChange = { inputBackendUrl = it },
                    label = { Text("Base URL", color = TextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrandCyan,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = SurfaceDark,
                        unfocusedContainerColor = SurfaceDark
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setBackendUrl(inputBackendUrl)
                        showBackendDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandCyan)
                ) {
                    Text("ذخیره", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBackendDialog = false }) {
                    Text("انصراف", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun SwitchSettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(text = subtitle, color = TextSecondary, fontSize = 11.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = BrandCyan,
                uncheckedTrackColor = SurfaceDark
            )
        )
    }
}
