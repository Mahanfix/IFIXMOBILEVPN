package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServerEntity
import com.example.ui.components.AddConfigBottomSheet
import com.example.ui.components.QrDialog
import com.example.ui.components.ServerItemCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.ServersViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServersScreen(
    viewModel: ServersViewModel,
    onNavigateBack: () -> Unit,
    onOpenQrScanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    var showAddSheet by remember { mutableStateOf(false) }
    var shareQrServer by remember { mutableStateOf<ServerEntity?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    val filteredServers = remember(state.servers, state.searchQuery, state.selectedProtocol) {
        state.servers.filter { srv ->
            val matchQuery = state.searchQuery.isBlank() ||
                    srv.name.contains(state.searchQuery, ignoreCase = true) ||
                    srv.countryName.contains(state.searchQuery, ignoreCase = true) ||
                    srv.host.contains(state.searchQuery, ignoreCase = true)

            val matchProtocol = state.selectedProtocol == "ALL" ||
                    srv.protocol.equals(state.selectedProtocol, ignoreCase = true)

            matchQuery && matchProtocol
        }
    }

    LaunchedEffect(state.message) {
        state.message?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        containerColor = BackgroundDark,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "لیست سرورها و کانفیگ‌ها",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, "بازگشت", tint = TextPrimary)
                    }
                },
                actions = {
                    // Test All Pings button
                    IconButton(
                        onClick = { viewModel.testAllPings() },
                        enabled = !state.isTestingAllPing
                    ) {
                        if (state.isTestingAllPing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = BrandCyan,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(Icons.Default.Speed, "تست پینگ همه", tint = BrandCyan)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddSheet = true },
                containerColor = BrandCyan,
                contentColor = Color.Black,
                shape = CircleShape,
                modifier = Modifier.testTag("add_config_fab")
            ) {
                Icon(Icons.Default.Add, "افزودن سرور")
            }
        },
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Search Bar
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text("جستجوی نام کشور یا سرور…", color = TextDisabled) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = TextSecondary) },
                trailingIcon = {
                    if (state.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                            Icon(Icons.Default.Close, "پاک کردن", tint = TextSecondary)
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrandCyan,
                    unfocusedBorderColor = SurfaceCardBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = SurfaceCardDark,
                    unfocusedContainerColor = SurfaceCardDark
                ),
                shape = RoundedCornerShape(14.dp)
            )

            // Protocol Filter Chips
            val protocols = listOf("ALL" to "همه", "VLESS" to "VLESS", "VMESS" to "VMess", "TROJAN" to "Trojan", "SHADOWSOCKS" to "Shadowsocks")
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(protocols) { (key, label) ->
                    val isSelected = state.selectedProtocol == key
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectProtocolFilter(key) },
                        label = {
                            Text(
                                text = label,
                                color = if (isSelected) Color.Black else TextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BrandCyan,
                            containerColor = SurfaceCardDark
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = SurfaceCardBorder,
                            selectedBorderColor = BrandCyan
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Servers List
            if (filteredServers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Dns, null, tint = TextDisabled, modifier = Modifier.size(54.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "سروری یافت نشد",
                            color = TextSecondary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredServers, key = { it.id }) { server ->
                        ServerItemCard(
                            server = server,
                            isSelected = server.isSelected,
                            onSelect = { viewModel.selectServer(server.id) },
                            onTestPing = { viewModel.testPing(server) },
                            onDelete = { viewModel.deleteServer(server.id) },
                            onShare = { shareQrServer = server }
                        )
                    }
                }
            }
        }
    }

    // Add Config Modal Bottom Sheet
    if (showAddSheet) {
        AddConfigBottomSheet(
            onDismiss = { showAddSheet = false },
            onPasteConfig = { raw -> viewModel.addConfig(raw) },
            onScanQr = onOpenQrScanner,
            onImportSubscription = { url -> viewModel.importSubscription(url) }
        )
    }

    // QR Share Dialog
    shareQrServer?.let { server ->
        val shareLink = server.rawConfig.ifEmpty { "vless://default@${server.host}:${server.port}" }
        QrDialog(
            title = "اشتراک‌گذاری ${server.name}",
            contentString = shareLink,
            onDismiss = { shareQrServer = null }
        )
    }
}
