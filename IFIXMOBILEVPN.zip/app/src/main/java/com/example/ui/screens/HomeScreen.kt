package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.V2RayParser
import com.example.data.model.VpnStatus
import com.example.ui.components.CyberCard
import com.example.ui.components.MetricCard
import com.example.ui.components.PowerButton
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToServers: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val vpnStatus by viewModel.vpnStatus.collectAsState()
    val activeServer by viewModel.activeServer.collectAsState()
    val stats by viewModel.trafficStats.collectAsState()

    Scaffold(
        containerColor = BackgroundDark,
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // 1. Top Header with Brand & Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(SurfaceCardDark)
                            .border(1.5.dp, BrandCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_ifix_logo),
                            contentDescription = "Logo",
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "IFIXVPN",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "IFIX MOBILE",
                            color = BrandCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Status Badge Pill
                val statusBg = when (vpnStatus) {
                    VpnStatus.CONNECTED -> StatusConnected.copy(alpha = 0.15f)
                    VpnStatus.CONNECTING, VpnStatus.DISCONNECTING -> StatusConnecting.copy(alpha = 0.15f)
                    VpnStatus.DISCONNECTED, VpnStatus.RECONNECTING -> StatusDisconnected.copy(alpha = 0.15f)
                }
                val statusText = when (vpnStatus) {
                    VpnStatus.CONNECTED -> "متصل"
                    VpnStatus.CONNECTING -> "اتصال…"
                    VpnStatus.DISCONNECTING -> "قطع…"
                    VpnStatus.RECONNECTING -> "مجدد…"
                    VpnStatus.DISCONNECTED -> "غیرفعال"
                }
                val statusColor = when (vpnStatus) {
                    VpnStatus.CONNECTED -> StatusConnected
                    VpnStatus.CONNECTING, VpnStatus.DISCONNECTING -> StatusConnecting
                    VpnStatus.DISCONNECTED, VpnStatus.RECONNECTING -> StatusDisconnected
                }

                Surface(
                    color = statusBg,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, statusColor.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = statusText,
                            color = statusColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 2. Selected Server Card
            val flag = activeServer?.let { V2RayParser.getCountryFlag(it.countryCode) } ?: "🇩🇪"
            val serverTitle = activeServer?.name ?: "IFIX DE 01 - Frankfurt"
            val protocol = activeServer?.protocol?.uppercase() ?: "VLESS"
            val ping = if (vpnStatus == VpnStatus.CONNECTED) "${stats.pingMs} ms" else "${activeServer?.pingMs ?: 45} ms"

            Surface(
                onClick = onNavigateToServers,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .border(BorderStroke(1.dp, SurfaceCardBorder), RoundedCornerShape(20.dp))
                    .testTag("selected_server_card"),
                color = SurfaceCardDark,
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(SurfaceDark)
                            .border(1.dp, SurfaceCardBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = flag, fontSize = 24.sp)
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = serverTitle,
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "پروتکل: $protocol",
                                color = BrandCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "• پینگ: $ping",
                                color = StatusConnected,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronLeft,
                        contentDescription = "تغییر سرور",
                        tint = TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // 3. Central Power Button
            PowerButton(
                status = vpnStatus,
                onClick = { viewModel.toggleVpn(context) },
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // Duration Ticker
            Text(
                text = if (vpnStatus == VpnStatus.CONNECTED) stats.formatDuration() else "آماده اتصال",
                color = if (vpnStatus == VpnStatus.CONNECTED) BrandCyan else TextSecondary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(28.dp))

            // 4. Live Metrics Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "سرعت دانلود",
                    value = if (vpnStatus == VpnStatus.CONNECTED) stats.formatDownloadSpeed() else "0 KB/s",
                    icon = Icons.Default.ArrowDownward,
                    iconColor = StatusConnected,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = "سرعت آپلود",
                    value = if (vpnStatus == VpnStatus.CONNECTED) stats.formatUploadSpeed() else "0 KB/s",
                    icon = Icons.Default.ArrowUpward,
                    iconColor = BrandCyan,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "آی‌پی اتصال (IP)",
                    value = if (vpnStatus == VpnStatus.CONNECTED) stats.currentIp else "مخفی نشده",
                    icon = Icons.Default.Public,
                    iconColor = BrandIndigo,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = "پینگ زنده",
                    value = ping,
                    icon = Icons.Default.Speed,
                    iconColor = StatusConnecting,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}
