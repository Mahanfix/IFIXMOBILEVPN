package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.SubscriptionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(
    viewModel: SubscriptionViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    val usedPercent = if (state.trafficLimitGB > 0) {
        ((state.trafficUsedGB / state.trafficLimitGB) * 100).coerceIn(0.0, 100.0).toFloat()
    } else 0f

    val animatedProgress by animateFloatAsState(
        targetValue = usedPercent / 100f,
        label = "usageProgress"
    )

    LaunchedEffect(state.message) {
        state.message?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        containerColor = BackgroundDark,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "مدیریت اشتراک و ترافیک",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, "بازگشت", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        },
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // 1. Plan Card
            CyberCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "پلن اشتراک شما",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "IFIX ${state.planType}",
                            color = TextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Surface(
                        color = BrandCyan.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, BrandCyan.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "وضعیت: فعال",
                            color = BrandCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Progress Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "مصرف حجم: ${state.trafficUsedGB} گیگابایت",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "کل: ${state.trafficLimitGB} GB",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp)
                        .clip(CircleShape),
                    color = if (usedPercent > 85) StatusDisconnected else BrandCyan,
                    trackColor = SurfaceDark
                )

                Spacer(modifier = Modifier.height(8.dp))

                val remainingGB = String.format(java.util.Locale.US, "%.1f", (state.trafficLimitGB - state.trafficUsedGB).coerceAtLeast(0.0))
                Text(
                    text = "$remainingGB گیگابایت باقیمانده (${100 - usedPercent.toInt()}%)",
                    color = BrandCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Subscription Details Card
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "اطلاعات دوره و دستگاه‌ها",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(14.dp))

                DetailRow(title = "تاریخ شروع", value = state.startDate, icon = Icons.Default.CalendarToday)
                HorizontalDivider(color = SurfaceCardBorder, modifier = Modifier.padding(vertical = 10.dp))

                DetailRow(title = "تاریخ انقضا", value = state.expiresAt, icon = Icons.Default.Event)
                HorizontalDivider(color = SurfaceCardBorder, modifier = Modifier.padding(vertical = 10.dp))

                DetailRow(
                    title = "دستگاه‌های متصل",
                    value = "${state.activeDevices} از ${state.maxDevices} دستگاه",
                    icon = Icons.Default.Devices
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 3. Sync & Update Button
            Button(
                onClick = { viewModel.refreshSubscription() },
                enabled = !state.isUpdating,
                colors = ButtonDefaults.buttonColors(containerColor = BrandCyan),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("sync_subscription_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                if (state.isUpdating) {
                    CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("در حال دریافت کانفیگ‌های جدید…", color = Color.Black, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.Sync, null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("بروزرسانی اشتراک و سرورها", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun DetailRow(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Text(text = title, color = TextSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.weight(1f))
        Text(text = value, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
