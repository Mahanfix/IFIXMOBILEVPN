package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.DeviceManager
import com.example.ui.components.CyberCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.LicenseViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    viewModel: LicenseViewModel,
    onNavigateBack: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var showLogoutDialog by remember { mutableStateOf(false) }

    val license = state.license
    val deviceId = remember { DeviceManager.getDeviceId(context) }
    val deviceModel = remember { DeviceManager.getDeviceModel() }

    Scaffold(
        containerColor = BackgroundDark,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "حساب کاربری و دستگاه‌ها",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, "بازگشت", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        },
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Profile Header Card
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(SurfaceDark)
                            .border(1.5.dp, BrandCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_ifix_logo),
                            contentDescription = "Logo",
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "کاربر لایسنس ${license?.plan ?: "Premium"}",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "شناسه کاربر: ${license?.userId?.ifEmpty { "usr-ifix-active" } ?: "usr-ifix-active"}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    Surface(
                        color = StatusConnected.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "تاییدشده",
                            color = StatusConnected,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // License Info Card
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "کد لایسنس شما",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = license?.licenseKey ?: "IFIX-PRO-2026-8899",
                        color = BrandCyan,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    IconButton(onClick = {
                        license?.licenseKey?.let {
                            clipboardManager.setText(AnnotatedString(it))
                        }
                    }) {
                        Icon(Icons.Default.ContentCopy, "کپی لایسنس", tint = BrandCyan, modifier = Modifier.size(20.dp))
                    }
                }

                HorizontalDivider(color = SurfaceCardBorder, modifier = Modifier.padding(vertical = 8.dp))

                Text(
                    text = "شناسه امن این دستگاه (Device ID):",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = deviceId,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Connected Devices
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "دستگاه‌های مجاز متصل (${state.devices.size} از ${license?.maxDevices ?: 2})",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (state.devices.isEmpty()) {
                    Text(
                        text = "• $deviceModel (این دستگاه - متصل)",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                } else {
                    state.devices.forEach { dev ->
                        Surface(
                            color = SurfaceDark,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, SurfaceCardBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhoneAndroid,
                                    contentDescription = null,
                                    tint = if (dev.isCurrentDevice) BrandCyan else TextSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (dev.isCurrentDevice) "${dev.deviceModel} (این دستگاه)" else dev.deviceModel,
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "آخرین فعالیت: ${dev.lastActive.ifEmpty { "هم‌اکنون" }}",
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }

                                if (!dev.isCurrentDevice) {
                                    IconButton(onClick = { viewModel.removeDevice(dev.deviceId) }) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "حذف دستگاه",
                                            tint = StatusDisconnected,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Logout Button
            OutlinedButton(
                onClick = { showLogoutDialog = true },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDisconnected),
                border = BorderStroke(1.dp, StatusDisconnected.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("logout_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Logout, null, tint = StatusDisconnected)
                Spacer(modifier = Modifier.width(8.dp))
                Text("خروج از حساب و تعویض لایسنس", color = StatusDisconnected, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            containerColor = SurfaceCardDark,
            title = { Text("خروج از حساب کاربری", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("آیا از خروج از لایسنس و حذف اطلاعات اطمینان دارید؟", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false
                        viewModel.logout()
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDisconnected)
                ) {
                    Text("خروج", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("انصراف", color = TextSecondary)
                }
            }
        )
    }
}
