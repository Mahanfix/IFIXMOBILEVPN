package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

sealed class Screen(val route: String, val title: String, val icon: ImageVector, val selectedIcon: ImageVector) {
    data object Home : Screen("home", "خانه", Icons.Outlined.Home, Icons.Filled.Home)
    data object Servers : Screen("servers", "سرورها", Icons.Outlined.Dns, Icons.Filled.Dns)
    data object Subscription : Screen("subscription", "اشتراک", Icons.Outlined.AutoGraph, Icons.Filled.AutoGraph)
    data object Account : Screen("account", "حساب", Icons.Outlined.Person, Icons.Filled.Person)
    data object Settings : Screen("settings", "تنظیمات", Icons.Outlined.Settings, Icons.Filled.Settings)

    data object License : Screen("license", "لایسنس", Icons.Default.Key, Icons.Filled.Key)
    data object Admin : Screen("admin", "مدیریت", Icons.Default.AdminPanelSettings, Icons.Filled.AdminPanelSettings)
    data object QrScanner : Screen("qr_scanner", "اسکنر", Icons.Default.QrCodeScanner, Icons.Filled.QrCodeScanner)
}

val bottomNavItems = listOf(
    Screen.Home,
    Screen.Servers,
    Screen.Subscription,
    Screen.Account,
    Screen.Settings
)

@Composable
fun AppBottomNavigationBar(
    currentRoute: String?,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        containerColor = SurfaceDark,
        tonalElevation = 8.dp,
        modifier = modifier
    ) {
        bottomNavItems.forEach { screen ->
            val isSelected = currentRoute == screen.route
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(screen.route) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) screen.selectedIcon else screen.icon,
                        contentDescription = screen.title
                    )
                },
                label = {
                    Text(
                        text = screen.title,
                        color = if (isSelected) BrandCyan else TextSecondary
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = BrandCyan,
                    indicatorColor = BrandCyan,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary
                )
            )
        }
    }
}
