package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.AppSettings
import com.example.data.repository.LicenseRepository
import com.example.data.repository.LicenseResult
import com.example.data.repository.ServerRepository
import com.example.data.repository.SettingsRepository
import com.example.vpn.VpnController
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// -------------------------------------------------------------
// 1. License ViewModel
// -------------------------------------------------------------
data class LicenseUiState(
    val isLicensed: Boolean = false,
    val license: LicenseEntity? = null,
    val isLoading: Boolean = true,
    val isActivating: Boolean = false,
    val errorMessage: String? = null,
    val devices: List<DeviceEntity> = emptyList()
)

class LicenseViewModel(
    private val licenseRepo: LicenseRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(LicenseUiState())
    val uiState: StateFlow<LicenseUiState> = _uiState.asStateFlow()

    init {
        checkCurrentLicense()
    }

    private fun checkCurrentLicense() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val cached = licenseRepo.getCachedLicense()
            if (cached != null && cached.isCachedValid) {
                _uiState.update {
                    it.copy(
                        isLicensed = true,
                        license = cached,
                        isLoading = false
                    )
                }
                loadDevices(cached.licenseKey)
                // Background validation with server
                licenseRepo.validateLicense()
            } else {
                _uiState.update { it.copy(isLicensed = false, isLoading = false) }
            }
        }
    }

    fun activateLicense(key: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isActivating = true, errorMessage = null) }
            when (val result = licenseRepo.activateLicense(key)) {
                is LicenseResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLicensed = true,
                            license = result.license,
                            isActivating = false,
                            errorMessage = null
                        )
                    }
                    loadDevices(result.license.licenseKey)
                }
                is LicenseResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isActivating = false,
                            errorMessage = result.message
                        )
                    }
                }
            }
        }
    }

    private fun loadDevices(key: String) {
        viewModelScope.launch {
            licenseRepo.getDevicesFlow(key).collect { devList ->
                _uiState.update { it.copy(devices = devList) }
            }
        }
    }

    fun removeDevice(deviceId: String) {
        val currentKey = _uiState.value.license?.licenseKey ?: return
        viewModelScope.launch {
            licenseRepo.removeDevice(currentKey, deviceId)
        }
    }

    fun logout() {
        viewModelScope.launch {
            licenseRepo.logout()
            _uiState.update { LicenseUiState(isLicensed = false, isLoading = false) }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }
}

// -------------------------------------------------------------
// 2. Main / Home ViewModel
// -------------------------------------------------------------
class MainViewModel(
    private val serverRepo: ServerRepository,
    private val licenseRepo: LicenseRepository
) : ViewModel() {

    val vpnStatus: StateFlow<VpnStatus> = VpnController.vpnStatus
    val trafficStats: StateFlow<VpnTrafficStats> = VpnController.trafficStats
    val activeServer: StateFlow<ServerEntity?> = serverRepo.selectedServerFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun toggleVpn(context: Context) {
        viewModelScope.launch {
            // Verify license before connect
            val isValid = licenseRepo.validateLicense()
            if (!isValid) {
                return@launch
            }

            when (vpnStatus.value) {
                VpnStatus.CONNECTED, VpnStatus.CONNECTING -> {
                    VpnController.stopVpn(context)
                }
                VpnStatus.DISCONNECTED, VpnStatus.DISCONNECTING, VpnStatus.RECONNECTING -> {
                    val server = serverRepo.getSelectedServer()
                    if (server != null) {
                        VpnController.startVpn(context, server)
                    }
                }
            }
        }
    }

    fun connectServer(context: Context, server: ServerEntity) {
        viewModelScope.launch {
            serverRepo.selectServer(server.id)
            VpnController.startVpn(context, server)
        }
    }

    fun disconnect(context: Context) {
        VpnController.stopVpn(context)
    }
}

// -------------------------------------------------------------
// 3. Servers ViewModel
// -------------------------------------------------------------
data class ServersUiState(
    val servers: List<ServerEntity> = emptyList(),
    val searchQuery: String = "",
    val selectedProtocol: String = "ALL", // ALL, VLESS, VMESS, TROJAN, SS
    val isTestingAllPing: Boolean = false,
    val message: String? = null
)

class ServersViewModel(
    private val serverRepo: ServerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ServersUiState())
    val uiState: StateFlow<ServersUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            serverRepo.serversFlow.collect { list ->
                _uiState.update { it.copy(servers = list) }
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun selectProtocolFilter(protocol: String) {
        _uiState.update { it.copy(selectedProtocol = protocol) }
    }

    fun selectServer(serverId: Long) {
        viewModelScope.launch {
            serverRepo.selectServer(serverId)
        }
    }

    fun addConfig(rawConfig: String) {
        viewModelScope.launch {
            val server = serverRepo.addConfig(rawConfig)
            if (server != null) {
                _uiState.update { it.copy(message = "سرور با موفقیت اضافه شد.") }
            } else {
                _uiState.update { it.copy(message = "خطا: فرمت کانفیگ معتبر نیست.") }
            }
        }
    }

    fun importSubscription(url: String) {
        viewModelScope.launch {
            val count = serverRepo.updateSubscription(url)
            _uiState.update { it.copy(message = "$count سرور با موفقیت بروزرسانی شد.") }
        }
    }

    fun deleteServer(serverId: Long) {
        viewModelScope.launch {
            serverRepo.deleteServer(serverId)
        }
    }

    fun testPing(server: ServerEntity) {
        viewModelScope.launch {
            serverRepo.testPing(server)
        }
    }

    fun testAllPings() {
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingAllPing = true) }
            serverRepo.testAllPings()
            _uiState.update { it.copy(isTestingAllPing = false) }
        }
    }

    fun clearMessage() {
        _uiState.update { it.copy(message = null) }
    }
}

// -------------------------------------------------------------
// 4. Subscription ViewModel
// -------------------------------------------------------------
data class SubscriptionUiState(
    val planType: String = "Premium",
    val startDate: String = "1404/10/20",
    val expiresAt: String = "1405/10/20",
    val trafficUsedGB: Double = 35.5,
    val trafficLimitGB: Double = 100.0,
    val activeDevices: Int = 1,
    val maxDevices: Int = 2,
    val isUpdating: Boolean = false,
    val message: String? = null
)

class SubscriptionViewModel(
    private val licenseRepo: LicenseRepository,
    private val serverRepo: ServerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SubscriptionUiState())
    val uiState: StateFlow<SubscriptionUiState> = _uiState.asStateFlow()

    init {
        loadSubscription()
    }

    private fun loadSubscription() {
        viewModelScope.launch {
            licenseRepo.licenseFlow.collect { license ->
                if (license != null) {
                    _uiState.update {
                        it.copy(
                            planType = license.plan,
                            startDate = if (license.activatedAt.isNotEmpty()) license.activatedAt.take(10) else "1404/10/20",
                            expiresAt = if (license.expiresAt.isNotEmpty()) license.expiresAt.take(10) else "1405/10/20",
                            trafficUsedGB = license.trafficUsedGB,
                            trafficLimitGB = license.trafficLimitGB,
                            activeDevices = license.currentDevices,
                            maxDevices = license.maxDevices
                        )
                    }
                }
            }
        }
    }

    fun refreshSubscription() {
        viewModelScope.launch {
            _uiState.update { it.copy(isUpdating = true) }
            licenseRepo.validateLicense()
            serverRepo.updateSubscription("https://api.ifixvpn.net/api/configs")
            _uiState.update {
                it.copy(
                    isUpdating = false,
                    message = "اشتراک و سرورها با موفقیت بروزرسانی شدند."
                )
            }
        }
    }

    fun clearMessage() {
        _uiState.update { it.copy(message = null) }
    }
}

// -------------------------------------------------------------
// 5. Settings ViewModel
// -------------------------------------------------------------
class SettingsViewModel(
    private val settingsRepo: SettingsRepository
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepo.settings

    fun setKillSwitch(enabled: Boolean) = settingsRepo.updateKillSwitch(enabled)
    fun setAutoConnect(enabled: Boolean) = settingsRepo.updateAutoConnect(enabled)
    fun setStartOnBoot(enabled: Boolean) = settingsRepo.updateStartOnBoot(enabled)
    fun setDns(dns: String) = settingsRepo.updateDns(dns)
    fun setMtu(mtu: Int) = settingsRepo.updateMtu(mtu)
    fun setRoutingMode(mode: String) = settingsRepo.updateRoutingMode(mode)
    fun setBackendUrl(url: String) = settingsRepo.updateBackendUrl(url)
    fun setNotifications(enabled: Boolean) = settingsRepo.updateNotifications(enabled)
}
