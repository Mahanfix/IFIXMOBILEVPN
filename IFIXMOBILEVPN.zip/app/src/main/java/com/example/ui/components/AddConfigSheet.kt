package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddConfigBottomSheet(
    onDismiss: () -> Unit,
    onPasteConfig: (String) -> Unit,
    onScanQr: () -> Unit,
    onImportSubscription: (String) -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    var inputConfig by remember { mutableStateOf("") }
    var inputSubUrl by remember { mutableStateOf("") }
    var activeTab by remember { mutableIntStateOf(0) } // 0: Paste, 1: Subscription

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SurfaceCardDark,
        dragHandle = { BottomSheetDefaults.DragHandle(color = TextSecondary) },
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp)
                .navigationBarsPadding()
        ) {
            Text(
                text = "افزودن سرور و کانفیگ جدید",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Option Buttons (QR Scanner & Clipboard)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickImportOption(
                    title = "اسکن کد QR",
                    icon = Icons.Default.QrCodeScanner,
                    onClick = {
                        onDismiss()
                        onScanQr()
                    },
                    modifier = Modifier.weight(1f)
                )

                QuickImportOption(
                    title = "خواندن از کلیپ‌بورد",
                    icon = Icons.Default.ContentPaste,
                    onClick = {
                        val text = clipboardManager.getText()?.text ?: ""
                        if (text.isNotBlank()) {
                            if (text.startsWith("http://") || text.startsWith("https://")) {
                                inputSubUrl = text
                                activeTab = 1
                            } else {
                                inputConfig = text
                                activeTab = 0
                            }
                        }
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tab Selector: Single Link vs Subscription URL
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = SurfaceDark,
                contentColor = BrandCyan,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    text = { Text("لینک مستقیم (VLESS/VMess)", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    text = { Text("لینک اشتراک (Sub URL)", fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (activeTab == 0) {
                OutlinedTextField(
                    value = inputConfig,
                    onValueChange = { inputConfig = it },
                    label = { Text("لینک کانفیگ (vless://, vmess://, trojan://, ss://)", color = TextSecondary) },
                    placeholder = { Text("vless://...", color = TextDisabled) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrandCyan,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = SurfaceDark,
                        unfocusedContainerColor = SurfaceDark
                    ),
                    shape = RoundedCornerShape(14.dp),
                    maxLines = 4
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (inputConfig.isNotBlank()) {
                            onPasteConfig(inputConfig)
                            onDismiss()
                        }
                    },
                    enabled = inputConfig.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Add, null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("افزودن و ذخیره کانفیگ", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            } else {
                OutlinedTextField(
                    value = inputSubUrl,
                    onValueChange = { inputSubUrl = it },
                    label = { Text("آدرس لینک اشتراک (Subscription URL)", color = TextSecondary) },
                    placeholder = { Text("https://example.com/sub/...", color = TextDisabled) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrandCyan,
                        unfocusedBorderColor = SurfaceCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = SurfaceDark,
                        unfocusedContainerColor = SurfaceDark
                    ),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (inputSubUrl.isNotBlank()) {
                            onImportSubscription(inputSubUrl)
                            onDismiss()
                        }
                    },
                    enabled = inputSubUrl.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.CloudDownload, null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("دریافت و بروزرسانی سرورها", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun QuickImportOption(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        color = SurfaceDark,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, SurfaceCardBorder),
        modifier = modifier.height(68.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(BrandCyan.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = BrandCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
