package com.example.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

object PingTester {

    /**
     * Measures real socket connection latency (RTT) in milliseconds.
     * Connects to target host and port via TCP handshake.
     */
    suspend fun testSocketPing(host: String, port: Int = 443, timeoutMs: Int = 3000): Int = withContext(Dispatchers.IO) {
        if (host.isBlank()) return@withContext -1

        var socket: Socket? = null
        try {
            val startTime = System.currentTimeMillis()
            socket = Socket()
            socket.connect(InetSocketAddress(host, if (port > 0) port else 443), timeoutMs)
            val rtt = (System.currentTimeMillis() - startTime).toInt()
            rtt.coerceAtLeast(1)
        } catch (e: Exception) {
            -1 // Timeout or unreachable
        } finally {
            try {
                socket?.close()
            } catch (_: Exception) {}
        }
    }
}
