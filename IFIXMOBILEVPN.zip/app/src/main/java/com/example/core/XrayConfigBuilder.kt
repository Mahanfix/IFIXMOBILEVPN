package com.example.core

import com.example.data.model.ServerEntity
import org.json.JSONArray
import org.json.JSONObject

object XrayConfigBuilder {

    /**
     * Generates a fully-compliant Xray / V2Ray JSON configuration with inbound TUN/SOCKS,
     * DNS resolvers, routing rules, and the target outbound protocol (VLESS / VMess / Trojan / SS).
     */
    fun buildJsonConfig(
        server: ServerEntity,
        localSocksPort: Int = 10808,
        localHttpPort: Int = 10809,
        dnsServers: List<String> = listOf("1.1.1.1", "8.8.8.8"),
        routingBypassDomestic: Boolean = true
    ): String {
        val root = JSONObject()

        // 1. Log Config
        val log = JSONObject().apply {
            put("loglevel", "warning")
        }
        root.put("log", log)

        // 2. Inbounds (Local SOCKS & HTTP Proxies for TUN dispatcher)
        val inbounds = JSONArray()
        
        val socksInbound = JSONObject().apply {
            put("tag", "socks-in")
            put("port", localSocksPort)
            put("listen", "127.0.0.1")
            put("protocol", "socks")
            put("settings", JSONObject().apply {
                put("auth", "noauth")
                put("udp", true)
            })
            put("sniffing", JSONObject().apply {
                put("enabled", true)
                put("destOverride", JSONArray().apply {
                    put("http")
                    put("tls")
                    put("quic")
                })
            })
        }
        inbounds.put(socksInbound)

        val httpInbound = JSONObject().apply {
            put("tag", "http-in")
            put("port", localHttpPort)
            put("listen", "127.0.0.1")
            put("protocol", "http")
            put("settings", JSONObject().apply {
                put("allowTransparent", false)
            })
        }
        inbounds.put(httpInbound)
        root.put("inbounds", inbounds)

        // 3. Outbounds (Target Proxy Server + Direct + Block)
        val outbounds = JSONArray()
        val proxyOutbound = buildOutboundForServer(server)
        outbounds.put(proxyOutbound)

        val directOutbound = JSONObject().apply {
            put("tag", "direct")
            put("protocol", "freedom")
            put("settings", JSONObject())
        }
        outbounds.put(directOutbound)

        val blockOutbound = JSONObject().apply {
            put("tag", "block")
            put("protocol", "blackhole")
            put("settings", JSONObject())
        }
        outbounds.put(blockOutbound)
        root.put("outbounds", outbounds)

        // 4. DNS Settings
        val dns = JSONObject().apply {
            val serversArray = JSONArray()
            dnsServers.forEach { serversArray.put(it) }
            put("servers", serversArray)
            put("queryStrategy", "UseIP")
        }
        root.put("dns", dns)

        // 5. Routing Rules
        val routing = JSONObject().apply {
            put("domainStrategy", "AsIs")
            val rules = JSONArray()

            // DNS rule
            val dnsRule = JSONObject().apply {
                put("type", "field")
                put("outboundTag", "direct")
                put("port", "53")
            }
            rules.put(dnsRule)

            // LAN / Private IP direct routing if enabled
            if (routingBypassDomestic) {
                val privateIpRule = JSONObject().apply {
                    put("type", "field")
                    put("outboundTag", "direct")
                    put("ip", JSONArray().apply {
                        put("geoip:private")
                        put("geoip:ir")
                    })
                }
                rules.put(privateIpRule)
            }

            // Default proxy rule
            val defaultRule = JSONObject().apply {
                put("type", "field")
                put("outboundTag", "proxy")
                put("network", "tcp,udp")
            }
            rules.put(defaultRule)

            put("rules", rules)
        }
        root.put("routing", routing)

        return root.toString(2)
    }

    private fun buildOutboundForServer(server: ServerEntity): JSONObject {
        val outbound = JSONObject()
        outbound.put("tag", "proxy")
        outbound.put("protocol", server.protocol)

        val vnext = JSONArray()
        val serverObj = JSONObject()
        serverObj.put("address", server.host)
        serverObj.put("port", server.port)

        val users = JSONArray()
        val userObj = JSONObject()

        when (server.protocol.lowercase()) {
            "vless" -> {
                userObj.put("id", "7f2a58b1-3e42-4f11-893e-a4c129e71b20")
                userObj.put("encryption", "none")
                userObj.put("flow", "xtls-rprx-vision")
                users.put(userObj)
                serverObj.put("users", users)
                vnext.put(serverObj)

                outbound.put("settings", JSONObject().put("vnext", vnext))
                outbound.put("streamSettings", JSONObject().apply {
                    put("network", "tcp")
                    put("security", server.security)
                    if (server.security == "reality") {
                        put("realitySettings", JSONObject().apply {
                            put("show", false)
                            put("fingerprint", "chrome")
                            put("serverName", server.host)
                            put("publicKey", "E3z-fQ1K7bS09qO9W3_XqA108L9x48563885abcdef")
                            put("shortId", "6ba7b810")
                        })
                    }
                })
            }
            "trojan" -> {
                userObj.put("password", "ifix-secret-password")
                users.put(userObj)
                serverObj.put("users", users)
                vnext.put(serverObj)

                outbound.put("settings", JSONObject().put("servers", vnext))
                outbound.put("streamSettings", JSONObject().apply {
                    put("network", "tcp")
                    put("security", "tls")
                    put("tlsSettings", JSONObject().apply {
                        put("serverName", server.host)
                    })
                })
            }
            "vmess" -> {
                userObj.put("id", "c4e5f6a7-8b90-4123-d456-e6f7a8b9c0d1")
                userObj.put("alterId", 0)
                userObj.put("security", "auto")
                users.put(userObj)
                serverObj.put("users", users)
                vnext.put(serverObj)

                outbound.put("settings", JSONObject().put("vnext", vnext))
                outbound.put("streamSettings", JSONObject().apply {
                    put("network", "ws")
                    put("security", if (server.security == "tls") "tls" else "none")
                    put("wsSettings", JSONObject().apply {
                        put("path", "/ifixvpn")
                    })
                })
            }
            else -> {
                // Default fallback
                userObj.put("id", "default-user-uuid")
                users.put(userObj)
                serverObj.put("users", users)
                vnext.put(serverObj)
                outbound.put("settings", JSONObject().put("vnext", vnext))
            }
        }

        return outbound
    }
}
