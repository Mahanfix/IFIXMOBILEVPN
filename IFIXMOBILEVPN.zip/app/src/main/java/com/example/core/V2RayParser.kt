package com.example.core

import android.net.Uri
import android.util.Base64
import com.example.data.model.ServerEntity
import org.json.JSONObject
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

data class ParsedV2RayConfig(
    val name: String,
    val protocol: String, // vless, vmess, trojan, shadowsocks
    val host: String,
    val port: Int,
    val uuidOrPassword: String,
    val security: String = "none", // reality, tls, none
    val network: String = "tcp", // tcp, ws, grpc, h2
    val path: String = "",
    val serverName: String = "",
    val publicKey: String = "",
    val shortId: String = "",
    val fingerprint: String = "chrome",
    val flow: String = "",
    val rawUri: String = ""
)

object V2RayParser {

    fun parseLink(link: String): ServerEntity? {
        val trimmed = link.trim()
        return try {
            when {
                trimmed.startsWith("vless://", ignoreCase = true) -> parseVless(trimmed)
                trimmed.startsWith("vmess://", ignoreCase = true) -> parseVmess(trimmed)
                trimmed.startsWith("trojan://", ignoreCase = true) -> parseTrojan(trimmed)
                trimmed.startsWith("ss://", ignoreCase = true) -> parseShadowsocks(trimmed)
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun parseSubscription(content: String): List<ServerEntity> {
        val servers = mutableListOf<ServerEntity>()
        var text = content.trim()

        // Check if content is Base64 encoded
        try {
            val decodedBytes = Base64.decode(text, Base64.DEFAULT)
            val decoded = String(decodedBytes, StandardCharsets.UTF_8).trim()
            if (decoded.contains("://")) {
                text = decoded
            }
        } catch (_: Exception) {}

        val lines = text.split("\n", "\r\n")
        var sortIndex = 1
        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isNotEmpty()) {
                val server = parseLink(trimmed)
                if (server != null) {
                    servers.add(server.copy(sortOrder = sortIndex++))
                }
            }
        }
        return servers
    }

    private fun parseVless(uriStr: String): ServerEntity? {
        val uri = Uri.parse(uriStr)
        val userInfo = uri.userInfo ?: ""
        val host = uri.host ?: return null
        val port = if (uri.port > 0) uri.port else 443
        val rawFragment = uri.fragment ?: ""
        val name = decodeUrl(if (rawFragment.isNotEmpty()) rawFragment else "IFIX VLESS $host")

        val security = uri.getQueryParameter("security") ?: "reality"
        val country = detectCountry(name, host)

        return ServerEntity(
            name = name,
            countryName = country.first,
            countryCode = country.second,
            host = host,
            port = port,
            protocol = "vless",
            security = security,
            serverLoad = (20..50).random(),
            pingMs = 0,
            isOnline = true,
            rawConfig = uriStr
        )
    }

    private fun parseTrojan(uriStr: String): ServerEntity? {
        val uri = Uri.parse(uriStr)
        val host = uri.host ?: return null
        val port = if (uri.port > 0) uri.port else 443
        val rawFragment = uri.fragment ?: ""
        val name = decodeUrl(if (rawFragment.isNotEmpty()) rawFragment else "IFIX Trojan $host")
        val security = uri.getQueryParameter("security") ?: "tls"
        val country = detectCountry(name, host)

        return ServerEntity(
            name = name,
            countryName = country.first,
            countryCode = country.second,
            host = host,
            port = port,
            protocol = "trojan",
            security = security,
            serverLoad = (20..45).random(),
            pingMs = 0,
            isOnline = true,
            rawConfig = uriStr
        )
    }

    private fun parseVmess(uriStr: String): ServerEntity? {
        val rawBase64 = uriStr.substring(8).trim()
        val jsonStr = String(Base64.decode(rawBase64, Base64.DEFAULT), StandardCharsets.UTF_8)
        val json = JSONObject(jsonStr)

        val host = json.optString("add", "")
        val port = json.optInt("port", 443)
        val remark = json.optString("ps", "IFIX VMess $host")
        val name = decodeUrl(remark)
        val tls = json.optString("tls", "none")
        val country = detectCountry(name, host)

        return ServerEntity(
            name = name,
            countryName = country.first,
            countryCode = country.second,
            host = host,
            port = port,
            protocol = "vmess",
            security = if (tls.equals("tls", true)) "tls" else "none",
            serverLoad = (30..60).random(),
            pingMs = 0,
            isOnline = true,
            rawConfig = uriStr
        )
    }

    private fun parseShadowsocks(uriStr: String): ServerEntity? {
        val uri = Uri.parse(uriStr)
        val host = uri.host ?: "ss.ifixvpn.net"
        val port = if (uri.port > 0) uri.port else 8388
        val rawFragment = uri.fragment ?: ""
        val name = decodeUrl(if (rawFragment.isNotEmpty()) rawFragment else "IFIX Shadowsocks $host")
        val country = detectCountry(name, host)

        return ServerEntity(
            name = name,
            countryName = country.first,
            countryCode = country.second,
            host = host,
            port = port,
            protocol = "shadowsocks",
            security = "none",
            serverLoad = (15..40).random(),
            pingMs = 0,
            isOnline = true,
            rawConfig = uriStr
        )
    }

    private fun decodeUrl(str: String): String {
        return try {
            URLDecoder.decode(str, StandardCharsets.UTF_8.name())
        } catch (_: Exception) {
            str
        }
    }

    fun detectCountry(name: String, host: String): Pair<String, String> {
        val lower = (name + " " + host).lowercase()
        return when {
            lower.contains("de") || lower.contains("germany") || lower.contains("آلمان") || lower.contains("frankfurt") || lower.contains("🇩🇪") ->
                Pair("آلمان", "DE")
            lower.contains("nl") || lower.contains("netherland") || lower.contains("هلند") || lower.contains("amsterdam") || lower.contains("🇳🇱") ->
                Pair("هلند", "NL")
            lower.contains("fi") || lower.contains("finland") || lower.contains("فنلاند") || lower.contains("helsinki") || lower.contains("🇫🇮") ->
                Pair("فنلاند", "FI")
            lower.contains("gb") || lower.contains("uk") || lower.contains("london") || lower.contains("انگلستان") || lower.contains("بریتانیا") || lower.contains("🇬🇧") ->
                Pair("انگلستان", "GB")
            lower.contains("tr") || lower.contains("turkey") || lower.contains("ترکیه") || lower.contains("istanbul") || lower.contains("🇹🇷") ->
                Pair("ترکیه", "TR")
            lower.contains("us") || lower.contains("usa") || lower.contains("america") || lower.contains("آمریکا") || lower.contains("🇺🇸") ->
                Pair("آمریکا", "US")
            lower.contains("fr") || lower.contains("france") || lower.contains("فرانسه") || lower.contains("paris") || lower.contains("🇫🇷") ->
                Pair("فرانسه", "FR")
            lower.contains("se") || lower.contains("sweden") || lower.contains("سوئد") || lower.contains("🇸🇪") ->
                Pair("سوئد", "SE")
            lower.contains("ca") || lower.contains("canada") || lower.contains("کانادا") || lower.contains("🇨🇦") ->
                Pair("کانادا", "CA")
            lower.contains("ae") || lower.contains("uae") || lower.contains("دبی") || lower.contains("امارات") || lower.contains("🇦🇪") ->
                Pair("امارات", "AE")
            else -> Pair("سرور بین‌المللی", "UN")
        }
    }

    fun getCountryFlag(countryCode: String): String {
        return when (countryCode.uppercase()) {
            "DE" -> "🇩🇪"
            "NL" -> "🇳🇱"
            "FI" -> "🇫🇮"
            "GB" -> "🇬🇧"
            "TR" -> "🇹🇷"
            "US" -> "🇺🇸"
            "FR" -> "🇫🇷"
            "SE" -> "🇸🇪"
            "CA" -> "🇨🇦"
            "AE" -> "🇦🇪"
            else -> "🌐"
        }
    }
}
