package com.example.core

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.provider.Settings
import java.security.MessageDigest
import java.util.UUID

object DeviceManager {
    private const val PREFS_NAME = "ifixvpn_device_prefs"
    private const val KEY_DEVICE_ID = "ifix_secure_device_id"

    @SuppressLint("HardwareIds")
    fun getDeviceId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedId = prefs.getString(KEY_DEVICE_ID, null)
        if (!savedId.isNullOrEmpty()) {
            return savedId
        }

        // Generate robust device identifier
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: ""
        val buildInfo = "${Build.BRAND}-${Build.MODEL}-${Build.HARDWARE}-${Build.FINGERPRINT}"
        val raw = if (androidId.isNotEmpty()) "$androidId-$buildInfo" else UUID.randomUUID().toString()

        val generatedId = "IFIX-DEV-" + sha256(raw).substring(0, 16).uppercase()
        prefs.edit().putString(KEY_DEVICE_ID, generatedId).apply()
        return generatedId
    }

    fun getDeviceModel(): String {
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        return if (model.startsWith(manufacturer, ignoreCase = true)) {
            model
        } else {
            "$manufacturer $model"
        }
    }

    fun getOsVersion(): String {
        return "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
