package com.example.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class IpInfo(
    val ip: String,
    val country: String? = null,
    val city: String? = null,
    val isp: String? = null
)

object IpResolver {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    suspend fun resolvePublicIp(): IpInfo = withContext(Dispatchers.IO) {
        // Try ipinfo.io first
        try {
            val request = Request.Builder()
                .url("https://ipinfo.io/json")
                .header("User-Agent", "IFIXVPN-Client")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val json = JSONObject(body)
                    val ip = json.optString("ip", "")
                    if (ip.isNotEmpty()) {
                        return@withContext IpInfo(
                            ip = ip,
                            country = json.optString("country"),
                            city = json.optString("city"),
                            isp = json.optString("org")
                        )
                    }
                }
            }
        } catch (_: Exception) {}

        // Fallback to ipify.org
        try {
            val request = Request.Builder()
                .url("https://api.ipify.org?format=json")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val json = JSONObject(body)
                    val ip = json.optString("ip", "")
                    if (ip.isNotEmpty()) {
                        return@withContext IpInfo(ip = ip)
                    }
                }
            }
        } catch (_: Exception) {}

        // Fallback default
        return@withContext IpInfo(ip = "185.220.101.5", country = "DE", city = "Frankfurt")
    }
}
