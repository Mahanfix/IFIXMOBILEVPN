package com.example.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.IfixDatabase
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val settingsRepo = SettingsRepository(context)
            if (settingsRepo.settings.value.startOnBoot) {
                CoroutineScope(Dispatchers.IO).launch {
                    val db = IfixDatabase.getInstance(context)
                    val server = db.serverDao().getSelectedServer() ?: db.serverDao().getAllServers().firstOrNull()
                    if (server != null) {
                        VpnController.startVpn(context, server)
                    }
                }
            }
        }
    }
}
