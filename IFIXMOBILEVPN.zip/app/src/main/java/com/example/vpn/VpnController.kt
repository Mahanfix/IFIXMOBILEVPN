package com.example.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.example.data.model.ServerEntity
import com.example.data.model.VpnStatus
import com.example.data.model.VpnTrafficStats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object VpnController {
    private val _vpnStatus = MutableStateFlow(VpnStatus.DISCONNECTED)
    val vpnStatus: StateFlow<VpnStatus> = _vpnStatus.asStateFlow()

    private val _activeServer = MutableStateFlow<ServerEntity?>(null)
    val activeServer: StateFlow<ServerEntity?> = _activeServer.asStateFlow()

    private val _trafficStats = MutableStateFlow(VpnTrafficStats())
    val trafficStats: StateFlow<VpnTrafficStats> = _trafficStats.asStateFlow()

    fun updateStatus(status: VpnStatus) {
        _vpnStatus.value = status
    }

    fun setActiveServer(server: ServerEntity?) {
        _activeServer.value = server
    }

    fun updateStats(stats: VpnTrafficStats) {
        _trafficStats.value = stats
    }

    fun startVpn(context: Context, server: ServerEntity) {
        _activeServer.value = server
        _vpnStatus.value = VpnStatus.CONNECTING

        val intent = Intent(context, IfixVpnService::class.java).apply {
            action = IfixVpnService.ACTION_CONNECT
            putExtra(IfixVpnService.EXTRA_SERVER_ID, server.id)
            putExtra(IfixVpnService.EXTRA_SERVER_NAME, server.name)
            putExtra(IfixVpnService.EXTRA_SERVER_HOST, server.host)
            putExtra(IfixVpnService.EXTRA_SERVER_PORT, server.port)
            putExtra(IfixVpnService.EXTRA_SERVER_PROTOCOL, server.protocol)
            putExtra(IfixVpnService.EXTRA_SERVER_FLAG, server.countryCode)
        }

        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } catch (e: Exception) {
            _vpnStatus.value = VpnStatus.DISCONNECTED
        }
    }

    fun stopVpn(context: Context) {
        _vpnStatus.value = VpnStatus.DISCONNECTING
        val intent = Intent(context, IfixVpnService::class.java).apply {
            action = IfixVpnService.ACTION_DISCONNECT
        }
        try {
            context.startService(intent)
        } catch (_: Exception) {
            _vpnStatus.value = VpnStatus.DISCONNECTED
        }
    }
}
