package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

enum class VpnStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    RECONNECTING
}

enum class LicenseStatus(val persianTitle: String) {
    ACTIVE("فعال"),
    EXPIRED("منقضی شده"),
    SUSPENDED("مسدود شده"),
    INACTIVE("غیرفعال"),
    DEVICE_LIMIT("محدودیت دستگاه");

    companion object {
        fun fromString(value: String?): LicenseStatus {
            return when (value?.lowercase()) {
                "active", "فعال" -> ACTIVE
                "expired", "منقضی شده" -> EXPIRED
                "suspended", "مسدود شده" -> SUSPENDED
                "inactive", "غیرفعال" -> INACTIVE
                "device_limit", "محدودیت دستگاه" -> DEVICE_LIMIT
                else -> ACTIVE
            }
        }
    }
}

@Entity(tableName = "servers")
data class ServerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val countryName: String,
    val countryCode: String,
    val host: String,
    val port: Int = 443,
    val protocol: String = "vless", // vless, vmess, trojan, shadowsocks
    val security: String = "reality", // reality, tls, none
    val serverLoad: Int = 25,
    val pingMs: Int = 0,
    val isOnline: Boolean = true,
    val isSelected: Boolean = false,
    val rawConfig: String = "",
    val sortOrder: Int = 0,
    val lastPingTimestamp: Long = 0L
)

@Entity(tableName = "license")
data class LicenseEntity(
    @PrimaryKey val licenseKey: String,
    val userId: String = "",
    val plan: String = "Premium",
    val status: String = "active",
    val maxDevices: Int = 2,
    val currentDevices: Int = 1,
    val trafficLimitGB: Double = 100.0,
    val trafficUsedGB: Double = 0.0,
    val createdAt: String = "",
    val activatedAt: String = "",
    val expiresAt: String = "",
    val isCachedValid: Boolean = true,
    val lastValidatedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey val deviceId: String,
    val licenseKey: String,
    val deviceModel: String,
    val osVersion: String,
    val ipAddress: String,
    val registeredAt: String,
    val lastActive: String,
    val isCurrentDevice: Boolean = false
)

data class VpnTrafficStats(
    val downloadSpeedBytes: Long = 0L,
    val uploadSpeedBytes: Long = 0L,
    val totalDownloadBytes: Long = 0L,
    val totalUploadBytes: Long = 0L,
    val durationSeconds: Long = 0L,
    val pingMs: Int = 0,
    val currentIp: String = "185.220.101.5"
) {
    fun formatDownloadSpeed(): String {
        val mbps = downloadSpeedBytes / (1024.0 * 1024.0)
        return if (mbps >= 0.1) String.format(java.util.Locale.US, "%.1f MB/s", mbps)
        else String.format(java.util.Locale.US, "%.0f KB/s", downloadSpeedBytes / 1024.0)
    }

    fun formatUploadSpeed(): String {
        val mbps = uploadSpeedBytes / (1024.0 * 1024.0)
        return if (mbps >= 0.1) String.format(java.util.Locale.US, "%.1f MB/s", mbps)
        else String.format(java.util.Locale.US, "%.0f KB/s", uploadSpeedBytes / 1024.0)
    }

    fun formatDuration(): String {
        val hours = durationSeconds / 3600
        val minutes = (durationSeconds % 3600) / 60
        val seconds = durationSeconds % 60
        return String.format(java.util.Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }
}
