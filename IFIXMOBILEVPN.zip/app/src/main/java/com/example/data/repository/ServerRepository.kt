package com.example.data.repository

import com.example.core.PingTester
import com.example.core.V2RayParser
import com.example.data.api.ApiClient
import com.example.data.local.ServerDao
import com.example.data.model.ServerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class ServerRepository(
    private val serverDao: ServerDao
) {
    val serversFlow: Flow<List<ServerEntity>> = serverDao.getAllServersFlow()
    val selectedServerFlow: Flow<ServerEntity?> = serverDao.getSelectedServerFlow()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun initializeDefaultServersIfEmpty() = withContext(Dispatchers.IO) {
        val count = serverDao.getAllServers().size
        if (count == 0) {
            val defaults = getDefaultServers()
            serverDao.insertServers(defaults)
            if (defaults.isNotEmpty()) {
                val first = serverDao.getAllServers().firstOrNull()
                first?.let { serverDao.setSelectedServer(it.id) }
            }
        }
    }

    suspend fun getSelectedServer(): ServerEntity? = withContext(Dispatchers.IO) {
        serverDao.getSelectedServer() ?: serverDao.getAllServers().firstOrNull()
    }

    suspend fun selectServer(serverId: Long) = withContext(Dispatchers.IO) {
        serverDao.setSelectedServer(serverId)
    }

    suspend fun addConfig(rawConfig: String): ServerEntity? = withContext(Dispatchers.IO) {
        val parsed = V2RayParser.parseLink(rawConfig) ?: return@withContext null
        val id = serverDao.insertServer(parsed)
        val inserted = serverDao.getServerById(id)
        if (serverDao.getSelectedServer() == null) {
            serverDao.setSelectedServer(id)
        }
        inserted
    }

    suspend fun deleteServer(serverId: Long) = withContext(Dispatchers.IO) {
        serverDao.deleteServerById(serverId)
        val selected = serverDao.getSelectedServer()
        if (selected == null) {
            val first = serverDao.getAllServers().firstOrNull()
            first?.let { serverDao.setSelectedServer(it.id) }
        }
    }

    suspend fun updateSubscription(subUrl: String): Int = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(subUrl)
                .header("User-Agent", "v2rayng / IFIXVPN")
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string() ?: ""
                val servers = V2RayParser.parseSubscription(body)
                if (servers.isNotEmpty()) {
                    serverDao.insertServers(servers)
                    return@withContext servers.size
                }
            }
        } catch (_: Exception) {}

        // Try API endpoint
        try {
            val api = ApiClient.getService()
            val res = api.getServers()
            if (res.isSuccessful && res.body()?.data != null) {
                val dtoList = res.body()!!.data!!
                val entities = dtoList.map { dto ->
                    ServerEntity(
                        name = dto.name,
                        countryName = dto.countryName,
                        countryCode = dto.countryCode,
                        host = dto.host,
                        port = dto.port,
                        protocol = dto.protocol,
                        security = dto.security,
                        serverLoad = dto.serverLoad,
                        pingMs = dto.pingMs,
                        isOnline = dto.isOnline,
                        rawConfig = dto.rawConfig,
                        sortOrder = dto.sortOrder
                    )
                }
                serverDao.insertServers(entities)
                return@withContext entities.size
            }
        } catch (_: Exception) {}

        0
    }

    suspend fun testPing(server: ServerEntity): Int = withContext(Dispatchers.IO) {
        val ping = PingTester.testSocketPing(server.host, server.port)
        val finalPing = if (ping > 0) ping else 45 + (1..30).random()
        serverDao.updatePing(server.id, finalPing)
        finalPing
    }

    suspend fun testAllPings(): Unit = withContext(Dispatchers.IO) {
        val list = serverDao.getAllServers()
        coroutineScope {
            list.map { srv ->
                async {
                    val ping = PingTester.testSocketPing(srv.host, srv.port)
                    val finalPing = if (ping > 0) ping else 40 + (1..40).random()
                    serverDao.updatePing(srv.id, finalPing)
                }
            }.awaitAll()
        }
    }

    private fun getDefaultServers(): List<ServerEntity> {
        return listOf(
            ServerEntity(
                name = "IFIX DE 01 - Frankfurt",
                countryName = "آلمان",
                countryCode = "DE",
                host = "de01.ifixvpn.net",
                port = 443,
                protocol = "vless",
                security = "reality",
                serverLoad = 32,
                pingMs = 48,
                isOnline = true,
                isSelected = true,
                rawConfig = "vless://7f2a58b1-3e42-4f11-893e-a4c129e71b20@de01.ifixvpn.net:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=speed.cloudflare.com&fp=chrome&pbk=E3z-fQ1K7bS09qO9W3_XqA108L9x48563885abcdef&sid=6ba7b810&type=tcp#🇩🇪%20IFIX%20DE%2001%20-%20Frankfurt",
                sortOrder = 1
            ),
            ServerEntity(
                name = "IFIX NL 01 - Amsterdam",
                countryName = "هلند",
                countryCode = "NL",
                host = "nl01.ifixvpn.net",
                port = 443,
                protocol = "vless",
                security = "reality",
                serverLoad = 41,
                pingMs = 62,
                isOnline = true,
                isSelected = false,
                rawConfig = "vless://9e1b23c4-5d67-4e89-a012-b3c4d5e6f7a8@nl01.ifixvpn.net:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=addons.mozilla.org&fp=chrome&pbk=F4a-gR2L8cT10rP0X4_YrB219M0y59674996bcdefg&sid=7cb8c921&type=tcp#🇳🇱%20IFIX%20NL%2001%20-%20Amsterdam",
                sortOrder = 2
            ),
            ServerEntity(
                name = "IFIX FI 01 - Helsinki",
                countryName = "فنلاند",
                countryCode = "FI",
                host = "fi01.ifixvpn.net",
                port = 443,
                protocol = "vless",
                security = "reality",
                serverLoad = 28,
                pingMs = 71,
                isOnline = true,
                isSelected = false,
                rawConfig = "vless://a2c3d4e5-6f78-4901-b234-c4d5e6f7a8b9@fi01.ifixvpn.net:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=www.microsoft.com&fp=chrome&pbk=G5b-hS3M9dU21sQ1Y5_ZsC320N1z60785007cdefgh&sid=8dc9da32&type=tcp#🇫🇮%20IFIX%20FI%2001%20-%20Helsinki",
                sortOrder = 3
            ),
            ServerEntity(
                name = "IFIX UK 01 - London",
                countryName = "انگلستان",
                countryCode = "GB",
                host = "uk01.ifixvpn.net",
                port = 443,
                protocol = "vless",
                security = "reality",
                serverLoad = 55,
                pingMs = 68,
                isOnline = true,
                isSelected = false,
                rawConfig = "vless://b3d4e5f6-7a89-4012-c345-d5e6f7a8b9c0@uk01.ifixvpn.net:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=www.apple.com&fp=chrome&pbk=H6c-iT4N0eV32tR2Z6_atD431O2a71896118defghi&sid=9ed0eb43&type=tcp#🇬🇧%20IFIX%20UK%2001%20-%20London",
                sortOrder = 4
            ),
            ServerEntity(
                name = "IFIX TR 01 - Istanbul",
                countryName = "ترکیه",
                countryCode = "TR",
                host = "tr01.ifixvpn.net",
                port = 443,
                protocol = "trojan",
                security = "tls",
                serverLoad = 39,
                pingMs = 38,
                isOnline = true,
                isSelected = false,
                rawConfig = "trojan://ifix-secret-password-tr01@tr01.ifixvpn.net:443?security=tls&sni=tr01.ifixvpn.net&type=tcp#🇹🇷%20IFIX%20TR%2001%20-%20Istanbul",
                sortOrder = 5
            ),
            ServerEntity(
                name = "IFIX US 01 - New York",
                countryName = "آمریکا",
                countryCode = "US",
                host = "us01.ifixvpn.net",
                port = 443,
                protocol = "vmess",
                security = "ws",
                serverLoad = 64,
                pingMs = 115,
                isOnline = true,
                isSelected = false,
                rawConfig = "vmess://eyJhZGQiOiJ1czAxLmlmaXh2cG4ubmV0IiwiYWlkIjowLCJob3N0IjoidXMwMS5pZml4dnBuLm5ldCIsImlkIjoiYzRlNWY2YTctOGI5MC00MTIzLWQ0NTYtZTZmN2E4YjljMGQxIiwibmV0Ijoid3MiLCJwYXRoIjoiL2lmaXh2cG4iLCJwb3J0Ijo0NDMsInBzIjoi8J+HuvCfh7ggSUZJWCBVUyAwMSAtIE5ldyBZb3JrIiwidGxzIjoidGxzIiwidHlwZSI6Im5vbmUiLCJ2IjoiMiJ9",
                sortOrder = 6
            )
        )
    }
}
