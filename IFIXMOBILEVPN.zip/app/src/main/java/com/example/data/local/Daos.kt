package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DeviceEntity
import com.example.data.model.LicenseEntity
import com.example.data.model.ServerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ServerDao {
    @Query("SELECT * FROM servers ORDER BY sortOrder ASC, id ASC")
    fun getAllServersFlow(): Flow<List<ServerEntity>>

    @Query("SELECT * FROM servers ORDER BY sortOrder ASC, id ASC")
    suspend fun getAllServers(): List<ServerEntity>

    @Query("SELECT * FROM servers WHERE isSelected = 1 LIMIT 1")
    fun getSelectedServerFlow(): Flow<ServerEntity?>

    @Query("SELECT * FROM servers WHERE isSelected = 1 LIMIT 1")
    suspend fun getSelectedServer(): ServerEntity?

    @Query("SELECT * FROM servers WHERE id = :id LIMIT 1")
    suspend fun getServerById(id: Long): ServerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServer(server: ServerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServers(servers: List<ServerEntity>)

    @Update
    suspend fun updateServer(server: ServerEntity)

    @Query("UPDATE servers SET pingMs = :pingMs, lastPingTimestamp = :timestamp WHERE id = :id")
    suspend fun updatePing(id: Long, pingMs: Int, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE servers SET isSelected = CASE WHEN id = :selectedId THEN 1 ELSE 0 END")
    suspend fun setSelectedServer(selectedId: Long)

    @Delete
    suspend fun deleteServer(server: ServerEntity)

    @Query("DELETE FROM servers WHERE id = :id")
    suspend fun deleteServerById(id: Long)

    @Query("DELETE FROM servers")
    suspend fun clearAll()
}

@Dao
interface LicenseDao {
    @Query("SELECT * FROM license LIMIT 1")
    fun getLicenseFlow(): Flow<LicenseEntity?>

    @Query("SELECT * FROM license LIMIT 1")
    suspend fun getLicense(): LicenseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLicense(license: LicenseEntity)

    @Query("UPDATE license SET isCachedValid = :isValid, status = :status, currentDevices = :currentDevices WHERE licenseKey = :key")
    suspend fun updateValidationStatus(key: String, isValid: Boolean, status: String, currentDevices: Int)

    @Query("DELETE FROM license")
    suspend fun clearLicense()
}

@Dao
interface DeviceDao {
    @Query("SELECT * FROM devices WHERE licenseKey = :licenseKey ORDER BY registeredAt DESC")
    fun getDevicesFlow(licenseKey: String): Flow<List<DeviceEntity>>

    @Query("SELECT * FROM devices WHERE licenseKey = :licenseKey")
    suspend fun getDevices(licenseKey: String): List<DeviceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevices(devices: List<DeviceEntity>)

    @Query("DELETE FROM devices WHERE deviceId = :deviceId")
    suspend fun deleteDevice(deviceId: String)

    @Query("DELETE FROM devices WHERE licenseKey = :licenseKey")
    suspend fun clearDevices(licenseKey: String)
}
