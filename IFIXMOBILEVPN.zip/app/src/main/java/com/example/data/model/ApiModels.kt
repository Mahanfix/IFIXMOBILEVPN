package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class LicenseActivateRequest(
    @Json(name = "license_key") val licenseKey: String,
    @Json(name = "device_id") val deviceId: String,
    @Json(name = "device_model") val deviceModel: String,
    @Json(name = "os_version") val osVersion: String
)

@JsonClass(generateAdapter = true)
data class LicenseValidateRequest(
    @Json(name = "license_key") val licenseKey: String,
    @Json(name = "device_id") val deviceId: String
)

@JsonClass(generateAdapter = true)
data class DeviceActionRequest(
    @Json(name = "license_key") val licenseKey: String,
    @Json(name = "device_id") val deviceId: String,
    @Json(name = "device_model") val deviceModel: String? = null,
    @Json(name = "os_version") val osVersion: String? = null
)

@JsonClass(generateAdapter = true)
data class DeviceDto(
    @Json(name = "device_id") val deviceId: String,
    @Json(name = "device_model") val deviceModel: String? = null,
    @Json(name = "os_version") val osVersion: String? = null,
    @Json(name = "ip_address") val ipAddress: String? = null,
    @Json(name = "registered_at") val registeredAt: String? = null,
    @Json(name = "last_active") val lastActive: String? = null
)

@JsonClass(generateAdapter = true)
data class LicenseDataDto(
    @Json(name = "license_key") val licenseKey: String,
    @Json(name = "user_id") val userId: String? = null,
    @Json(name = "plan") val plan: String = "Premium",
    @Json(name = "status") val status: String = "active",
    @Json(name = "max_devices") val maxDevices: Int = 2,
    @Json(name = "current_devices") val currentDevices: Int = 1,
    @Json(name = "traffic_limit_gb") val trafficLimitGB: Double = 100.0,
    @Json(name = "traffic_used_gb") val trafficUsedGB: Double = 0.0,
    @Json(name = "created_at") val createdAt: String? = null,
    @Json(name = "activated_at") val activatedAt: String? = null,
    @Json(name = "expires_at") val expiresAt: String = "",
    @Json(name = "token") val token: String? = null,
    @Json(name = "devices") val devices: List<DeviceDto>? = null
)

@JsonClass(generateAdapter = true)
data class ApiResponse<T>(
    @Json(name = "success") val success: Boolean,
    @Json(name = "message") val message: String? = null,
    @Json(name = "error_code") val errorCode: String? = null,
    @Json(name = "data") val data: T? = null,
    @Json(name = "devices") val devices: List<DeviceDto>? = null
)

@JsonClass(generateAdapter = true)
data class SubscriptionDataDto(
    @Json(name = "plan_type") val planType: String = "Premium",
    @Json(name = "start_date") val startDate: String = "",
    @Json(name = "expires_at") val expiresAt: String = "",
    @Json(name = "traffic_used_gb") val trafficUsedGB: Double = 0.0,
    @Json(name = "traffic_limit_gb") val trafficLimitGB: Double = 100.0,
    @Json(name = "traffic_remaining_gb") val trafficRemainingGB: Double = 100.0,
    @Json(name = "active_devices") val activeDevices: Int = 1,
    @Json(name = "max_devices") val maxDevices: Int = 2,
    @Json(name = "sub_url") val subUrl: String? = null,
    @Json(name = "devices") val devices: List<DeviceDto>? = null
)

@JsonClass(generateAdapter = true)
data class ServerDto(
    @Json(name = "id") val id: String,
    @Json(name = "name") val name: String,
    @Json(name = "country_name") val countryName: String,
    @Json(name = "country_code") val countryCode: String,
    @Json(name = "host") val host: String,
    @Json(name = "port") val port: Int = 443,
    @Json(name = "protocol") val protocol: String = "vless",
    @Json(name = "security") val security: String = "reality",
    @Json(name = "server_load") val serverLoad: Int = 20,
    @Json(name = "ping_ms") val pingMs: Int = 50,
    @Json(name = "is_online") val isOnline: Boolean = true,
    @Json(name = "raw_config") val rawConfig: String = "",
    @Json(name = "sort_order") val sortOrder: Int = 0
)

@JsonClass(generateAdapter = true)
data class ServerListResponse(
    @Json(name = "success") val success: Boolean,
    @Json(name = "count") val count: Int = 0,
    @Json(name = "data") val data: List<ServerDto>? = null
)
