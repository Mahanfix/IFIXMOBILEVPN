package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.api.ApiClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val killSwitchEnabled: Boolean = false,
    val autoConnectOnLaunch: Boolean = false,
    val startOnBoot: Boolean = false,
    val dnsServer: String = "1.1.1.1", // 1.1.1.1, 8.8.8.8, 9.9.9.9
    val mtu: Int = 1400,
    val routingMode: String = "bypass_domestic", // bypass_domestic, global
    val preferredProtocol: String = "vless_reality",
    val backendUrl: String = "https://api.ifixvpn.net/",
    val notificationsEnabled: Boolean = true,
    val isDarkMode: Boolean = true
)

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("ifixvpn_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadSettings(): AppSettings {
        return AppSettings(
            killSwitchEnabled = prefs.getBoolean("kill_switch", false),
            autoConnectOnLaunch = prefs.getBoolean("auto_connect", false),
            startOnBoot = prefs.getBoolean("start_on_boot", false),
            dnsServer = prefs.getString("dns_server", "1.1.1.1") ?: "1.1.1.1",
            mtu = prefs.getInt("mtu", 1400),
            routingMode = prefs.getString("routing_mode", "bypass_domestic") ?: "bypass_domestic",
            preferredProtocol = prefs.getString("preferred_protocol", "vless_reality") ?: "vless_reality",
            backendUrl = prefs.getString("backend_url", "https://api.ifixvpn.net/") ?: "https://api.ifixvpn.net/",
            notificationsEnabled = prefs.getBoolean("notifications_enabled", true),
            isDarkMode = prefs.getBoolean("is_dark_mode", true)
        )
    }

    fun updateKillSwitch(enabled: Boolean) {
        prefs.edit().putBoolean("kill_switch", enabled).apply()
        _settings.value = _settings.value.copy(killSwitchEnabled = enabled)
    }

    fun updateAutoConnect(enabled: Boolean) {
        prefs.edit().putBoolean("auto_connect", enabled).apply()
        _settings.value = _settings.value.copy(autoConnectOnLaunch = enabled)
    }

    fun updateStartOnBoot(enabled: Boolean) {
        prefs.edit().putBoolean("start_on_boot", enabled).apply()
        _settings.value = _settings.value.copy(startOnBoot = enabled)
    }

    fun updateDns(dns: String) {
        prefs.edit().putString("dns_server", dns).apply()
        _settings.value = _settings.value.copy(dnsServer = dns)
    }

    fun updateMtu(mtu: Int) {
        prefs.edit().putInt("mtu", mtu).apply()
        _settings.value = _settings.value.copy(mtu = mtu)
    }

    fun updateRoutingMode(mode: String) {
        prefs.edit().putString("routing_mode", mode).apply()
        _settings.value = _settings.value.copy(routingMode = mode)
    }

    fun updateBackendUrl(url: String) {
        prefs.edit().putString("backend_url", url).apply()
        _settings.value = _settings.value.copy(backendUrl = url)
        ApiClient.updateBaseUrl(url)
    }

    fun updateNotifications(enabled: Boolean) {
        prefs.edit().putBoolean("notifications_enabled", enabled).apply()
        _settings.value = _settings.value.copy(notificationsEnabled = enabled)
    }
}
