package com.example.data.api

import com.example.data.model.*
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface IfixApiService {

    @POST("api/license/activate")
    suspend fun activateLicense(
        @Body request: LicenseActivateRequest
    ): Response<ApiResponse<LicenseDataDto>>

    @POST("api/license/validate")
    suspend fun validateLicense(
        @Body request: LicenseValidateRequest
    ): Response<ApiResponse<LicenseDataDto>>

    @POST("api/device/register")
    suspend fun registerDevice(
        @Body request: DeviceActionRequest
    ): Response<ApiResponse<Unit>>

    @POST("api/device/remove")
    suspend fun removeDevice(
        @Body request: DeviceActionRequest
    ): Response<ApiResponse<Unit>>

    @GET("api/subscription")
    suspend fun getSubscription(
        @Query("license_key") licenseKey: String
    ): Response<ApiResponse<SubscriptionDataDto>>

    @GET("api/servers")
    suspend fun getServers(): Response<ServerListResponse>

    @GET("api/configs")
    suspend fun getSubscriptionConfigs(
        @Query("license_key") licenseKey: String,
        @Query("format") format: String? = null
    ): Response<String>
}
