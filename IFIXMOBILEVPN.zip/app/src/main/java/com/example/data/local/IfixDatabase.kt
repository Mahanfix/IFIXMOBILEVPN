package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.DeviceEntity
import com.example.data.model.LicenseEntity
import com.example.data.model.ServerEntity

@Database(
    entities = [ServerEntity::class, LicenseEntity::class, DeviceEntity::class],
    version = 1,
    exportSchema = false
)
abstract class IfixDatabase : RoomDatabase() {
    abstract fun serverDao(): ServerDao
    abstract fun licenseDao(): LicenseDao
    abstract fun deviceDao(): DeviceDao

    companion object {
        @Volatile
        private var INSTANCE: IfixDatabase? = null

        fun getInstance(context: Context): IfixDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    IfixDatabase::class.java,
                    "ifixvpn_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
