package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.navigation.AppBottomNavigationBar
import com.example.ui.navigation.Screen
import com.example.ui.navigation.bottomNavItems
import com.example.ui.screens.*
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as IfixApplication
        val factory = ViewModelFactory(app)

        setContent {
            MyApplicationTheme(darkTheme = true) {
                // Mandatory RTL support for complete Persian localization
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainAppContent(factory)
                }
            }
        }
    }
}

@Composable
fun MainAppContent(factory: ViewModelFactory) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val licenseViewModel: LicenseViewModel = viewModel(factory = factory)
    val mainViewModel: MainViewModel = viewModel(factory = factory)
    val serversViewModel: ServersViewModel = viewModel(factory = factory)
    val subscriptionViewModel: SubscriptionViewModel = viewModel(factory = factory)
    val settingsViewModel: SettingsViewModel = viewModel(factory = factory)

    val licenseState by licenseViewModel.uiState.collectAsState()

    // Android VpnService permission launcher
    val vpnLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        // VPN permission granted
    }

    // Android 13+ Notification Permission launcher
    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val startDestination = if (licenseState.isLicensed) Screen.Home.route else Screen.License.route
    val showBottomBar = bottomNavItems.any { it.route == currentRoute }

    Scaffold(
        containerColor = BackgroundDark,
        bottomBar = {
            if (showBottomBar) {
                AppBottomNavigationBar(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        navController.navigate(route) {
                            popUpTo(Screen.Home.route) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundDark)
        ) {
            composable(Screen.License.route) {
                LicenseScreen(
                    viewModel = licenseViewModel,
                    onLicensedSuccess = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.License.route) { inclusive = true }
                        }
                    },
                    onOpenQrScanner = {
                        navController.navigate(Screen.QrScanner.route)
                    }
                )
            }

            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = mainViewModel,
                    onNavigateToServers = { navController.navigate(Screen.Servers.route) },
                    onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                )
            }

            composable(Screen.Servers.route) {
                ServersScreen(
                    viewModel = serversViewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onOpenQrScanner = { navController.navigate(Screen.QrScanner.route) }
                )
            }

            composable(Screen.Subscription.route) {
                SubscriptionScreen(
                    viewModel = subscriptionViewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Account.route) {
                AccountScreen(
                    viewModel = licenseViewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onLogout = {
                        navController.navigate(Screen.License.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.Settings.route) {
                SettingsScreen(
                    viewModel = settingsViewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToAdmin = { navController.navigate(Screen.Admin.route) }
                )
            }

            composable(Screen.Admin.route) {
                AdminScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.QrScanner.route) {
                QrScannerScreen(
                    onQrCodeScanned = { scannedCode ->
                        if (scannedCode.startsWith("IFIX-", ignoreCase = true)) {
                            licenseViewModel.activateLicense(scannedCode)
                        } else {
                            serversViewModel.addConfig(scannedCode)
                        }
                        navController.popBackStack()
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}

