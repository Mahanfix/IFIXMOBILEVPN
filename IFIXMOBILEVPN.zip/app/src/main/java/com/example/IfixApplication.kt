package com.example

import android.app.Application
import com.example.data.api.ApiClient
import com.example.data.local.IfixDatabase
import com.example.data.repository.LicenseRepository
import com.example.data.repository.ServerRepository
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class IfixApplication : Application() {

    lateinit var database: IfixDatabase
        private set

    lateinit var licenseRepository: LicenseRepository
        private set

    lateinit var serverRepository: ServerRepository
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    override fun onCreate() {
        super.onCreate()

        database = IfixDatabase.getInstance(this)
        licenseRepository = LicenseRepository(this, database.licenseDao(), database.deviceDao())
        serverRepository = ServerRepository(database.serverDao())
        settingsRepository = SettingsRepository(this)

        // Initialize custom API URL if configured
        ApiClient.updateBaseUrl(settingsRepository.settings.value.backendUrl)

        // Populate default high-speed servers if empty
        CoroutineScope(Dispatchers.IO).launch {
            serverRepository.initializeDefaultServersIfEmpty()
        }
    }
}
