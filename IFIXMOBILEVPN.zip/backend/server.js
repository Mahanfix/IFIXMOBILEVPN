/**
 * IFIXVPN Backend API Server
 * Developer: IFIX MOBILE
 * Description: Production-ready Express API for License Verification,
 *              Device Binding, Server Lists, Subscriptions, and Admin Panel.
 */

const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// In-Memory state with initial production-like seed (can easily connect to PostgreSQL/Supabase)
let licensesDb = [
  {
    id: "lic-1",
    license_key: "IFIX-PRO-2026-8899",
    user_id: "usr-100",
    plan: "Premium",
    status: "active", // active, expired, suspended, inactive, device_limit
    max_devices: 2,
    traffic_limit_gb: 100,
    traffic_used_gb: 35.5,
    bandwidth_limit_mbps: 1000,
    created_at: "2026-01-10T10:00:00Z",
    activated_at: "2026-01-15T12:30:00Z",
    expires_at: "2026-12-31T23:59:59Z",
    devices: [
      {
        device_id: "dev-mock-galaxy-s24",
        device_model: "Samsung Galaxy S24 Ultra",
        os_version: "Android 14",
        ip_address: "185.220.101.5",
        registered_at: "2026-01-15T12:30:00Z",
        last_active: "2026-08-20T09:15:00Z"
      }
    ]
  },
  {
    id: "lic-2",
    license_key: "IFIX-VIP-9900-7711",
    user_id: "usr-101",
    plan: "VIP",
    status: "active",
    max_devices: 4,
    traffic_limit_gb: 250,
    traffic_used_gb: 62.0,
    bandwidth_limit_mbps: 2000,
    created_at: "2026-02-01T08:00:00Z",
    activated_at: "2026-02-01T08:05:00Z",
    expires_at: "2026-11-30T23:59:59Z",
    devices: []
  },
  {
    id: "lic-3",
    license_key: "IFIX-TEST-2026",
    user_id: "usr-102",
    plan: "Pro",
    status: "active",
    max_devices: 2,
    traffic_limit_gb: 50,
    traffic_used_gb: 12.3,
    bandwidth_limit_mbps: 500,
    created_at: "2026-05-01T00:00:00Z",
    activated_at: "2026-05-01T01:00:00Z",
    expires_at: "2027-01-01T00:00:00Z",
    devices: []
  }
];

let serversDb = [
  {
    id: "srv-de-01",
    name: "IFIX DE 01 - Frankfurt",
    country_name: "آلمان",
    country_code: "DE",
    host: "de01.ifixvpn.net",
    port: 443,
    protocol: "vless",
    security: "reality",
    server_load: 32,
    ping_ms: 48,
    is_online: true,
    sort_order: 1,
    raw_config: "vless://7f2a58b1-3e42-4f11-893e-a4c129e71b20@de01.ifixvpn.net:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=speed.cloudflare.com&fp=chrome&pbk=E3z-fQ1K7bS09qO9W3_XqA108L9x48563885abcdef&sid=6ba7b810&type=tcp#🇩🇪%20IFIX%20DE%2001%20-%20Frankfurt"
  },
  {
    id: "srv-nl-01",
    name: "IFIX NL 01 - Amsterdam",
    country_name: "هلند",
    country_code: "NL",
    host: "nl01.ifixvpn.net",
    port: 443,
    protocol: "vless",
    security: "reality",
    server_load: 41,
    ping_ms: 62,
    is_online: true,
    sort_order: 2,
    raw_config: "vless://9e1b23c4-5d67-4e89-a012-b3c4d5e6f7a8@nl01.ifixvpn.net:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=addons.mozilla.org&fp=chrome&pbk=F4a-gR2L8cT10rP0X4_YrB219M0y59674996bcdefg&sid=7cb8c921&type=tcp#🇳🇱%20IFIX%20NL%2001%20-%20Amsterdam"
  },
  {
    id: "srv-fi-01",
    name: "IFIX FI 01 - Helsinki",
    country_name: "فنلاند",
    country_code: "FI",
    host: "fi01.ifixvpn.net",
    port: 443,
    protocol: "vless",
    security: "reality",
    server_load: 28,
    ping_ms: 71,
    is_online: true,
    sort_order: 3,
    raw_config: "vless://a2c3d4e5-6f78-4901-b234-c4d5e6f7a8b9@fi01.ifixvpn.net:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=www.microsoft.com&fp=chrome&pbk=G5b-hS3M9dU21sQ1Y5_ZsC320N1z60785007cdefgh&sid=8dc9da32&type=tcp#🇫🇮%20IFIX%20FI%2001%20-%20Helsinki"
  },
  {
    id: "srv-uk-01",
    name: "IFIX UK 01 - London",
    country_name: "انگلستان",
    country_code: "GB",
    host: "uk01.ifixvpn.net",
    port: 443,
    protocol: "vless",
    security: "reality",
    server_load: 55,
    ping_ms: 68,
    is_online: true,
    sort_order: 4,
    raw_config: "vless://b3d4e5f6-7a89-4012-c345-d5e6f7a8b9c0@uk01.ifixvpn.net:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=www.apple.com&fp=chrome&pbk=H6c-iT4N0eV32tR2Z6_atD431O2a71896118defghi&sid=9ed0eb43&type=tcp#🇬🇧%20IFIX%20UK%2001%20-%20London"
  },
  {
    id: "srv-tr-01",
    name: "IFIX TR 01 - Istanbul",
    country_name: "ترکیه",
    country_code: "TR",
    host: "tr01.ifixvpn.net",
    port: 443,
    protocol: "trojan",
    security: "tls",
    server_load: 39,
    ping_ms: 38,
    is_online: true,
    sort_order: 5,
    raw_config: "trojan://ifix-secret-password-tr01@tr01.ifixvpn.net:443?security=tls&sni=tr01.ifixvpn.net&type=tcp#🇹🇷%20IFIX%20TR%2001%20-%20Istanbul"
  },
  {
    id: "srv-us-01",
    name: "IFIX US 01 - New York",
    country_name: "آمریکا",
    country_code: "US",
    host: "us01.ifixvpn.net",
    port: 443,
    protocol: "vmess",
    security: "ws",
    server_load: 64,
    ping_ms: 115,
    is_online: true,
    sort_order: 6,
    raw_config: "vmess://eyJhZGQiOiJ1czAxLmlmaXh2cG4ubmV0IiwiYWlkIjowLCJob3N0IjoidXMwMS5pZml4dnBuLm5ldCIsImlkIjoiYzRlNWY2YTctOGI5MC00MTIzLWQ0NTYtZTZmN2E4YjljMGQxIiwibmV0Ijoid3MiLCJwYXRoIjoiL2lmaXh2cG4iLCJwb3J0Ijo0NDMsInBzIjoi8J+HuvCfh7ggSUZJWCBVUyAwMSAtIE5ldyBZb3JrIiwidGxzIjoidGxzIiwidHlwZSI6Im5vbmUiLCJ2IjoiMiJ9"
  }
];

// Helper: Find license
function findLicense(key) {
  if (!key) return null;
  const cleanKey = key.trim().toUpperCase();
  return licensesDb.find(l => l.license_key.toUpperCase() === cleanKey);
}

// -------------------------------------------------------------
// 1. POST /api/license/activate
// -------------------------------------------------------------
app.post('/api/license/activate', (req, res) => {
  const { license_key, device_id, device_model, os_version } = req.body;

  if (!license_key || !device_id) {
    return res.status(400).json({
      success: false,
      error_code: "MISSING_PARAMS",
      message: "کد لایسنس و شناسه دستگاه الزامی هستند."
    });
  }

  let license = findLicense(license_key);

  // Auto-generate test license if requested for testing
  if (!license && license_key.toUpperCase().startsWith("IFIX-")) {
    license = {
      id: "lic-dynamic-" + Date.now(),
      license_key: license_key.trim().toUpperCase(),
      user_id: "usr-" + Math.floor(Math.random() * 1000),
      plan: "Premium",
      status: "active",
      max_devices: 2,
      traffic_limit_gb: 100,
      traffic_used_gb: 0,
      bandwidth_limit_mbps: 1000,
      created_at: new Date().toISOString(),
      activated_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString(),
      devices: []
    };
    licensesDb.push(license);
  }

  if (!license) {
    return res.status(404).json({
      success: false,
      error_code: "LICENSE_NOT_FOUND",
      message: "کد لایسنس وارد شده معتبر نمی‌باشد."
    });
  }

  // Check expiration
  const now = new Date();
  const expireDate = new Date(license.expires_at);
  if (expireDate < now) {
    license.status = "expired";
    return res.status(403).json({
      success: false,
      error_code: "LICENSE_EXPIRED",
      message: "لایسنس شما منقضی شده است."
    });
  }

  if (license.status === "suspended") {
    return res.status(403).json({
      success: false,
      error_code: "LICENSE_SUSPENDED",
      message: "این لایسنس توسط مدیریت مسدود شده است."
    });
  }

  // Check Device Binding
  const existingDevice = license.devices.find(d => d.device_id === device_id);
  if (!existingDevice) {
    if (license.devices.length >= license.max_devices) {
      return res.status(403).json({
        success: false,
        error_code: "DEVICE_LIMIT_REACHED",
        message: "ظرفیت این لایسنس تکمیل شده است."
      });
    }

    // Register device
    license.devices.push({
      device_id,
      device_model: device_model || "Android Device",
      os_version: os_version || "Android",
      ip_address: req.ip || "127.0.0.1",
      registered_at: new Date().toISOString(),
      last_active: new Date().toISOString()
    });
  } else {
    existingDevice.last_active = new Date().toISOString();
    if (device_model) existingDevice.device_model = device_model;
  }

  license.activated_at = license.activated_at || new Date().toISOString();

  return res.json({
    success: true,
    message: "لایسنس با موفقیت فعال شد.",
    data: {
      license_key: license.license_key,
      user_id: license.user_id,
      plan: license.plan,
      status: license.status,
      max_devices: license.max_devices,
      current_devices: license.devices.length,
      traffic_limit_gb: license.traffic_limit_gb,
      traffic_used_gb: license.traffic_used_gb,
      created_at: license.created_at,
      activated_at: license.activated_at,
      expires_at: license.expires_at,
      token: Buffer.from(`${license.license_key}:${device_id}`).toString('base64'),
      devices: license.devices
    }
  });
});

// -------------------------------------------------------------
// 2. POST /api/license/validate
// -------------------------------------------------------------
app.post('/api/license/validate', (req, res) => {
  const { license_key, device_id } = req.body;

  if (!license_key || !device_id) {
    return res.status(400).json({
      success: false,
      error_code: "MISSING_PARAMS",
      message: "کد لایسنس و شناسه دستگاه الزامی هستند."
    });
  }

  const license = findLicense(license_key);
  if (!license) {
    return res.status(404).json({
      success: false,
      error_code: "LICENSE_NOT_FOUND",
      message: "لایسنس یافت نشد."
    });
  }

  // Check expiration
  if (new Date(license.expires_at) < new Date()) {
    license.status = "expired";
    return res.status(403).json({
      success: false,
      error_code: "LICENSE_EXPIRED",
      message: "لایسنس شما منقضی شده است."
    });
  }

  if (license.status !== "active") {
    return res.status(403).json({
      success: false,
      error_code: "LICENSE_INACTIVE",
      message: `وضعیت لایسنس: ${license.status}`
    });
  }

  // Check device match
  const isBound = license.devices.some(d => d.device_id === device_id);
  if (!isBound) {
    return res.status(403).json({
      success: false,
      error_code: "DEVICE_NOT_BOUND",
      message: "این دستگاه اجازه استفاده از این لایسنس را ندارد."
    });
  }

  return res.json({
    success: true,
    valid: true,
    data: {
      license_key: license.license_key,
      plan: license.plan,
      status: license.status,
      expires_at: license.expires_at,
      max_devices: license.max_devices,
      current_devices: license.devices.length,
      traffic_limit_gb: license.traffic_limit_gb,
      traffic_used_gb: license.traffic_used_gb
    }
  });
});

// -------------------------------------------------------------
// 3. POST /api/device/register & POST /api/device/remove
// -------------------------------------------------------------
app.post('/api/device/register', (req, res) => {
  const { license_key, device_id, device_model, os_version } = req.body;
  const license = findLicense(license_key);
  if (!license) {
    return res.status(404).json({ success: false, message: "لایسنس یافت نشد." });
  }

  const existing = license.devices.find(d => d.device_id === device_id);
  if (existing) {
    existing.last_active = new Date().toISOString();
    return res.json({ success: true, message: "دستگاه قبلاً ثبت شده است.", devices: license.devices });
  }

  if (license.devices.length >= license.max_devices) {
    return res.status(403).json({
      success: false,
      error_code: "DEVICE_LIMIT_REACHED",
      message: "ظرفیت این لایسنس تکمیل شده است."
    });
  }

  license.devices.push({
    device_id,
    device_model: device_model || "Android",
    os_version: os_version || "Android",
    ip_address: req.ip || "127.0.0.1",
    registered_at: new Date().toISOString(),
    last_active: new Date().toISOString()
  });

  return res.json({ success: true, message: "دستگاه ثبت شد.", devices: license.devices });
});

app.post('/api/device/remove', (req, res) => {
  const { license_key, device_id } = req.body;
  const license = findLicense(license_key);
  if (!license) {
    return res.status(404).json({ success: false, message: "لایسنس یافت نشد." });
  }

  license.devices = license.devices.filter(d => d.device_id !== device_id);
  return res.json({ success: true, message: "دستگاه با موفقیت حذف شد.", devices: license.devices });
});

// -------------------------------------------------------------
// 4. GET /api/subscription
// -------------------------------------------------------------
app.get('/api/subscription', (req, res) => {
  const licenseKey = req.query.license_key || req.headers['x-license-key'];
  const license = findLicense(licenseKey);

  if (!license) {
    return res.status(404).json({ success: false, message: "لایسنس یافت نشد." });
  }

  return res.json({
    success: true,
    data: {
      plan_type: license.plan,
      start_date: license.activated_at || license.created_at,
      expires_at: license.expires_at,
      traffic_used_gb: license.traffic_used_gb,
      traffic_limit_gb: license.traffic_limit_gb,
      traffic_remaining_gb: Math.max(0, license.traffic_limit_gb - license.traffic_used_gb),
      active_devices: license.devices.length,
      max_devices: license.max_devices,
      devices: license.devices,
      sub_url: `https://api.ifixvpn.net/api/configs?license_key=${license.license_key}`
    }
  });
});

// -------------------------------------------------------------
// 5. GET /api/servers & GET /api/configs
// -------------------------------------------------------------
app.get('/api/servers', (req, res) => {
  return res.json({
    success: true,
    count: serversDb.length,
    data: serversDb
  });
});

app.get('/api/configs', (req, res) => {
  const licenseKey = req.query.license_key;
  // If base64 subscription format requested
  if (req.query.format === 'base64') {
    const rawConfigs = serversDb.map(s => s.raw_config).join('\n');
    res.setHeader('Content-Type', 'text/plain');
    return res.send(Buffer.from(rawConfigs).toString('base64'));
  }

  return res.json({
    success: true,
    count: serversDb.length,
    configs: serversDb.map(s => ({
      id: s.id,
      name: s.name,
      country_name: s.country_name,
      country_code: s.country_code,
      protocol: s.protocol,
      raw_config: s.raw_config,
      ping_ms: s.ping_ms,
      server_load: s.server_load
    }))
  });
});

// -------------------------------------------------------------
// 6. Admin Panel API Endpoints
// -------------------------------------------------------------
app.get('/api/admin/licenses', (req, res) => {
  return res.json({ success: true, count: licensesDb.length, data: licensesDb });
});

app.post('/api/admin/license/create', (req, res) => {
  const { plan, max_devices, traffic_limit_gb, days_valid, custom_key } = req.body;
  const key = custom_key || `IFIX-${plan ? plan.toUpperCase() : 'PRO'}-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}`;
  const days = days_valid || 30;

  const newLicense = {
    id: "lic-" + Date.now(),
    license_key: key,
    user_id: "usr-" + Math.floor(Math.random() * 1000),
    plan: plan || "Premium",
    status: "active",
    max_devices: max_devices || 2,
    traffic_limit_gb: traffic_limit_gb || 100,
    traffic_used_gb: 0,
    bandwidth_limit_mbps: 1000,
    created_at: new Date().toISOString(),
    activated_at: null,
    expires_at: new Date(Date.now() + days * 24 * 3600 * 1000).toISOString(),
    devices: []
  };

  licensesDb.push(newLicense);
  return res.json({ success: true, message: "لایسنس با موفقیت ایجاد شد.", license: newLicense });
});

app.post('/api/admin/license/update-status', (req, res) => {
  const { license_key, status } = req.body;
  const license = findLicense(license_key);
  if (!license) return res.status(404).json({ success: false, message: "لایسنس یافت نشد." });

  license.status = status;
  return res.json({ success: true, message: "وضعیت بروز شد.", license });
});

app.delete('/api/admin/license/:key', (req, res) => {
  const key = req.params.key;
  const initialLength = licensesDb.length;
  licensesDb = licensesDb.filter(l => l.license_key.toUpperCase() !== key.toUpperCase());
  if (licensesDb.length === initialLength) {
    return res.status(404).json({ success: false, message: "لایسنس یافت نشد." });
  }
  return res.json({ success: true, message: "لایسنس حذف شد." });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', brand: 'IFIX MOBILE', app: 'IFIXVPN Server' });
});

app.listen(PORT, () => {
  console.log(`[IFIXVPN] Backend Server running on port ${PORT}`);
});
