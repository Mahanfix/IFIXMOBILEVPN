-- ==========================================================
-- IFIXVPN Database Schema (PostgreSQL / Supabase)
-- Developer: IFIX MOBILE
-- Description: Complete schema for Users, Licenses, Devices,
--              Subscriptions, Servers, Configs, and Logs.
-- ==========================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE,
    phone VARCHAR(32) UNIQUE,
    full_name VARCHAR(128),
    role VARCHAR(32) DEFAULT 'customer', -- 'customer', 'admin', 'reseller'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Licenses Table
CREATE TABLE IF NOT EXISTS licenses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    license_key VARCHAR(64) UNIQUE NOT NULL,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    plan VARCHAR(64) NOT NULL DEFAULT 'Premium', -- 'Basic', 'Pro', 'Premium', 'VIP'
    status VARCHAR(32) NOT NULL DEFAULT 'active', -- 'active', 'expired', 'suspended', 'inactive', 'device_limit'
    max_devices INT NOT NULL DEFAULT 2,
    current_devices INT NOT NULL DEFAULT 0,
    traffic_limit_gb BIGINT NOT NULL DEFAULT 100,
    traffic_used_gb NUMERIC(10, 2) NOT NULL DEFAULT 0,
    bandwidth_limit_mbps INT DEFAULT 1000,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    activated_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    notes TEXT,
    created_by UUID REFERENCES users(id) ON DELETE SET NULL
);

-- 3. Devices Table (Device Binding)
CREATE TABLE IF NOT EXISTS devices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    license_id UUID NOT NULL REFERENCES licenses(id) ON DELETE CASCADE,
    device_id VARCHAR(128) NOT NULL,
    device_model VARCHAR(128),
    os_version VARCHAR(64),
    ip_address VARCHAR(64),
    last_active TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    registered_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT TRUE,
    CONSTRAINT unique_license_device UNIQUE (license_id, device_id)
);

-- 4. Subscriptions Table
CREATE TABLE IF NOT EXISTS subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    license_id UUID UNIQUE NOT NULL REFERENCES licenses(id) ON DELETE CASCADE,
    subscription_token VARCHAR(128) UNIQUE NOT NULL,
    sub_url TEXT,
    auto_update BOOLEAN DEFAULT TRUE,
    last_synced_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Servers Table
CREATE TABLE IF NOT EXISTS servers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(128) NOT NULL,
    country_name VARCHAR(64) NOT NULL,
    country_code VARCHAR(8) NOT NULL,
    host VARCHAR(255) NOT NULL,
    port INT NOT NULL DEFAULT 443,
    protocol VARCHAR(32) NOT NULL DEFAULT 'vless', -- 'vless', 'vmess', 'trojan', 'shadowsocks'
    security VARCHAR(32) DEFAULT 'reality', -- 'reality', 'tls', 'none'
    server_load INT DEFAULT 25,
    ping_ms INT DEFAULT 45,
    is_online BOOLEAN DEFAULT TRUE,
    is_vip_only BOOLEAN DEFAULT FALSE,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. Subscriptions Configs (Raw V2Ray/Xray Links)
CREATE TABLE IF NOT EXISTS subscriptions_configs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    server_id UUID REFERENCES servers(id) ON DELETE CASCADE,
    raw_config TEXT NOT NULL,
    protocol_type VARCHAR(32) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. License Logs (Audit Trail)
CREATE TABLE IF NOT EXISTS license_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    license_id UUID REFERENCES licenses(id) ON DELETE CASCADE,
    action VARCHAR(64) NOT NULL, -- 'activated', 'validated', 'device_added', 'device_removed', 'expired'
    device_id VARCHAR(128),
    ip_address VARCHAR(64),
    details JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for lightning fast queries
CREATE INDEX IF NOT EXISTS idx_licenses_key ON licenses(license_key);
CREATE INDEX IF NOT EXISTS idx_licenses_status ON licenses(status);
CREATE INDEX IF NOT EXISTS idx_devices_license ON devices(license_id);
CREATE INDEX IF NOT EXISTS idx_devices_devid ON devices(device_id);
CREATE INDEX IF NOT EXISTS idx_servers_online ON servers(is_online, sort_order);

-- Sample Data for Testing / Production Bootstrapping
INSERT INTO users (id, email, full_name, role)
VALUES ('a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d', 'admin@ifixmobile.ir', 'مدیر سیستم IFIX', 'admin')
ON CONFLICT (email) DO NOTHING;

INSERT INTO licenses (license_key, plan, status, max_devices, traffic_limit_gb, traffic_used_gb, expires_at)
VALUES 
('IFIX-PRO-2026-8899', 'Premium', 'active', 2, 100, 35.5, NOW() + INTERVAL '30 days'),
('IFIX-VIP-9900-7711', 'VIP', 'active', 4, 250, 62.0, NOW() + INTERVAL '90 days'),
('IFIX-TEST-2026', 'Pro', 'active', 2, 50, 12.3, NOW() + INTERVAL '14 days')
ON CONFLICT (license_key) DO NOTHING;

INSERT INTO servers (name, country_name, country_code, host, port, protocol, security, server_load, ping_ms, is_online, sort_order)
VALUES 
('IFIX DE 01 - Frankfurt', 'آلمان', 'DE', 'de01.ifixvpn.net', 443, 'vless', 'reality', 32, 48, TRUE, 1),
('IFIX NL 01 - Amsterdam', 'هلند', 'NL', 'nl01.ifixvpn.net', 443, 'vless', 'reality', 41, 62, TRUE, 2),
('IFIX FI 01 - Helsinki', 'فنلاند', 'FI', 'fi01.ifixvpn.net', 443, 'vless', 'reality', 28, 71, TRUE, 3),
('IFIX UK 01 - London', 'انگلستان', 'GB', 'uk01.ifixvpn.net', 443, 'vless', 'reality', 55, 68, TRUE, 4),
('IFIX TR 01 - Istanbul', 'ترکیه', 'TR', 'tr01.ifixvpn.net', 443, 'trojan', 'tls', 39, 38, TRUE, 5),
('IFIX US 01 - New York', 'آمریکا', 'US', 'us01.ifixvpn.net', 443, 'vmess', 'ws', 64, 115, TRUE, 6)
ON CONFLICT DO NOTHING;
